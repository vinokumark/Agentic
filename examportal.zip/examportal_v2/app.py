"""
ExamPortal - Flask Exam Portal
================================
Run:   python app.py
Open:  http://localhost:5000
Admin: admin / admin123

Requirements:
    pip install flask pypdf python-docx
"""

import os, re, json, sqlite3, threading, time
from pathlib import Path
from functools import wraps
from flask import (Flask, request, session, redirect, url_for,
                   jsonify, g, render_template)
from werkzeug.utils import secure_filename

try:
    from pypdf import PdfReader
    HAS_PDF = True
except ImportError:
    HAS_PDF = False

try:
    import docx as docxlib
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

# ─── config ──────────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
DB_PATH    = BASE_DIR / "examportal.db"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = "examportal-secret-key-change-in-prod"
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024   # 20 MB

# progress store: upload_id -> list of log dicts
PROGRESS: dict[str, list] = {}

# ─── database ─────────────────────────────────────────────────────────────────
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, check_same_thread=False)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
    return g.db

@app.teardown_appcontext
def close_db(_):
    db = g.pop("db", None)
    if db:
        db.close()

def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT    UNIQUE NOT NULL,
            password TEXT    NOT NULL,
            role     TEXT    NOT NULL DEFAULT 'student'
        );
        CREATE TABLE IF NOT EXISTS questions (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT    NOT NULL,
            opt_a    TEXT    NOT NULL,
            opt_b    TEXT    NOT NULL,
            opt_c    TEXT    NOT NULL,
            opt_d    TEXT    NOT NULL,
            answer   TEXT    NOT NULL,
            category TEXT    DEFAULT 'General',
            source   TEXT    DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS exams (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            title       TEXT    NOT NULL,
            student_id  INTEGER NOT NULL,
            time_limit  INTEGER NOT NULL DEFAULT 15,
            created_at  TEXT    DEFAULT (datetime('now')),
            status      TEXT    DEFAULT 'pending'
        );
        CREATE TABLE IF NOT EXISTS exam_questions (
            exam_id     INTEGER NOT NULL,
            question_id INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS results (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id      INTEGER NOT NULL,
            student_id   INTEGER NOT NULL,
            score        INTEGER NOT NULL,
            total        INTEGER NOT NULL,
            answers      TEXT    NOT NULL,
            submitted_at TEXT    DEFAULT (datetime('now'))
        );
        """)
        row = db.execute("SELECT id FROM users WHERE username='admin'").fetchone()
        if not row:
            db.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                       ("admin", "admin123", "admin"))
        db.commit()

# ─── auth helpers ─────────────────────────────────────────────────────────────
def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login_page"))
            if role and session.get("role") != role:
                return redirect(url_for("login_page"))
            return f(*args, **kwargs)
        return wrapped
    return decorator

# ─── file parsing ──────────────────────────────────────────────────────────────
def extract_text(filepath: Path, ext: str) -> str:
    if ext == ".pdf":
        if not HAS_PDF:
            return ""
        reader = PdfReader(str(filepath))
        return "\n".join(p.extract_text() or "" for p in reader.pages)
    elif ext == ".docx":
        if not HAS_DOCX:
            return ""
        doc = docxlib.Document(str(filepath))
        return "\n".join(p.text for p in doc.paragraphs)
    else:
        return filepath.read_text(errors="ignore")


def _norm_ans(letter: str) -> str:
    return letter.strip().upper()

def _make_q(question, opts, ans, category="Parsed"):
    """Validate one Q&A record. Returns None if invalid."""
    question = question.strip()
    ans      = _norm_ans(ans)
    if not question:
        return None
    if ans not in ("A", "B", "C", "D"):
        return None
    a = opts.get("A", "").strip()
    b = opts.get("B", "").strip()
    c = opts.get("C", "").strip()
    d = opts.get("D", "").strip()
    if not all([a, b, c, d]):
        return None
    return {"question": question, "opt_a": a, "opt_b": b,
            "opt_c": c, "opt_d": d, "answer": ans, "category": category}


def parse_qa(text: str) -> list[dict]:
    """
    Detect and extract MCQ Q&A pairs.  Five formats supported, tried in order.

    Format A  — Q-prefix, inline options (most common exported PDF style)
        Q1. Question text
        A) opt   B) opt   C) opt   D) opt
        Answer: B

    Format B  — Numbered, each option on its own line
        1. Question?
        a. opt
        b. opt
        c. opt
        d. opt
        Answer: b

    Format C  — "Question:" / "Correct Answer:" label style
        Question: Question text
        A: opt
        B: opt
        C: opt
        D: opt
        Correct Answer: A

    Format D  — Parenthesised options, bracketed answer
        5) Question text
        (A) opt
        (B) opt
        (C) opt
        (D) opt
        [Answer: B]

    Format E  — Dash-prefixed options
        Q10: Question text
        - A. opt
        - B. opt
        - C. opt
        - D. opt
        Answer - C
    """
    text = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")

    def split_blocks(pattern: str) -> list[str]:
        """Split on lookahead — delimiter stays at start of each part."""
        parts = re.split(pattern, text, flags=re.MULTILINE)
        return [p.strip() for p in parts if p and p.strip()]

    questions: list[dict] = []

    # ── Format A ──────────────────────────────────────────────────────────────
    # Q1. / Q1) / Q1: followed by all four options on ONE line (2+ spaces between)
    pat_a = re.compile(
        r"Q\s*\d+\s*[\.\):\-]\s*(.+?)\n"
        r"\s*[Aa]\s*[)\.]?\s*(.+?)"
        r"\s{2,}[Bb]\s*[)\.]?\s*(.+?)"
        r"\s{2,}[Cc]\s*[)\.]?\s*(.+?)"
        r"\s{2,}[Dd]\s*[)\.]?\s*(.+?)\n"
        r"\s*(?:Correct\s+)?[Aa]nswers?\s*[:\-]\s*([A-Da-d])",
        re.DOTALL
    )
    for m in pat_a.finditer(text):
        q = _make_q(m.group(1),
                    {"A": m.group(2), "B": m.group(3),
                     "C": m.group(4), "D": m.group(5)},
                    m.group(6))
        if q:
            questions.append(q)
    if questions:
        return questions

    # ── Format B ──────────────────────────────────────────────────────────────
    # Numbered question (1. / 1)) with a./b./c./d. on separate lines (NO dash)
    for block in split_blocks(r"\n(?=\d+\s*[\.\)]\s*\S)"):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) < 6:
            continue
        q_text = re.sub(r"^\d+\s*[\.\)]\s*", "", lines[0])
        opts: dict[str, str] = {}
        ans = ""
        for line in lines[1:]:
            # must start directly with letter (a. / a) — no leading dash)
            m = re.match(r"^([a-dA-D])\s*[\.\)]\s*(.+)", line)
            if m:
                opts[m.group(1).upper()] = m.group(2).strip()
                continue
            m = re.match(r"^(?:Correct\s+)?[Aa]ns(?:wer)?\s*[:\-–]\s*([A-Da-d])", line)
            if m:
                ans = m.group(1)
        q = _make_q(q_text, opts, ans)
        if q:
            questions.append(q)
    if questions:
        return questions

    # ── Format C ──────────────────────────────────────────────────────────────
    # "Question:" label, options as  A: text  or  A. text  (no dash prefix)
    for block in re.split(r"\n(?=[Qq]uestion\s*:)", text, flags=re.IGNORECASE):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) < 6:
            continue
        q_text = re.sub(r"^[Qq]uestion\s*:\s*", "", lines[0])
        opts = {}
        ans  = ""
        for line in lines[1:]:
            # strict: letter immediately followed by : or . (no optional space before)
            m = re.match(r"^([A-Da-d])[:.]\s+(.+)", line)
            if m and m.group(1).upper() in "ABCD":
                opts[m.group(1).upper()] = m.group(2).strip()
                continue
            m = re.match(r"^(?:Correct\s+)?[Aa]ns(?:wer)?\s*[:\-–]\s*([A-Da-d])", line)
            if m:
                ans = m.group(1)
        q = _make_q(q_text, opts, ans)
        if q:
            questions.append(q)
    if questions:
        return questions

    # ── Format D ──────────────────────────────────────────────────────────────
    # Numbered question, options as (A) text, answer as [Answer: B]
    for block in split_blocks(r"\n(?=\d+\s*[\.\)]\s*\S)"):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) < 6:
            continue
        q_text = re.sub(r"^\d+\s*[\.\)]\s*", "", lines[0])
        opts = {}
        ans  = ""
        for line in lines[1:]:
            m = re.match(r"^\(\s*([A-Da-d])\s*\)\s*(.+)", line)
            if m:
                opts[m.group(1).upper()] = m.group(2).strip()
                continue
            m = re.match(r"^\[(?:Correct\s+)?[Aa]ns(?:wer)?\s*[:\-–]?\s*([A-Da-d])\]", line)
            if m:
                ans = m.group(1)
                continue
            m = re.match(r"^(?:Correct\s+)?[Aa]ns(?:wer)?\s*[:\-–]\s*([A-Da-d])", line)
            if m:
                ans = m.group(1)
        q = _make_q(q_text, opts, ans)
        if q:
            questions.append(q)
    if questions:
        return questions

    # ── Format E ──────────────────────────────────────────────────────────────
    # Q10: / Q10. prefix, options as  - A. text  (dash + letter + dot)
    for block in split_blocks(r"\n(?=Q\s*\d+\s*[:\.\-])"):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) < 6:
            continue
        q_text = re.sub(r"^Q\s*\d+\s*[:\.\-]\s*", "", lines[0], flags=re.IGNORECASE)
        opts = {}
        ans  = ""
        for line in lines[1:]:
            m = re.match(r"^[-–]\s*([A-Da-d])\s*[\.\)]\s*(.+)", line)
            if m:
                opts[m.group(1).upper()] = m.group(2).strip()
                continue
            m = re.match(r"^(?:Correct\s+)?[Aa]ns(?:wer)?\s*[-:\s]\s*([A-Da-d])\b", line)
            if m:
                ans = m.group(1)
        q = _make_q(q_text, opts, ans)
        if q:
            questions.append(q)

    return questions

# ─── routes: auth ─────────────────────────────────────────────────────────────
@app.route("/")
def index():
    if "user_id" not in session:
        return redirect(url_for("login_page"))
    if session.get("role") == "admin":
        return redirect(url_for("admin_dashboard"))
    return redirect(url_for("student_dashboard"))

@app.route("/login", methods=["GET", "POST"])
def login_page():
    error = ""
    if request.method == "POST":
        uname = request.form.get("username", "").strip()
        pwd   = request.form.get("password", "").strip()
        db    = get_db()
        row   = db.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (uname, pwd)
        ).fetchone()
        if row:
            session["user_id"]  = row["id"]
            session["username"] = row["username"]
            session["role"]     = row["role"]
            return redirect(url_for("index"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login_page"))

# ─── routes: admin ────────────────────────────────────────────────────────────
@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    db = get_db()
    stats = {
        "questions": db.execute("SELECT COUNT(*) FROM questions").fetchone()[0],
        "students":  db.execute("SELECT COUNT(*) FROM users WHERE role='student'").fetchone()[0],
        "exams":     db.execute("SELECT COUNT(*) FROM exams").fetchone()[0],
        "results":   db.execute("SELECT COUNT(*) FROM results").fetchone()[0],
    }
    return render_template("admin.html", stats=stats, username=session["username"])

# ─── upload & parse ───────────────────────────────────────────────────────────
@app.route("/admin/upload", methods=["POST"])
@login_required("admin")
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file"}), 400
    f   = request.files["file"]
    ext = Path(f.filename).suffix.lower()
    if ext not in (".pdf", ".docx", ".txt"):
        return jsonify({"error": "Unsupported file type. Use PDF, DOCX, or TXT."}), 400

    uid      = str(int(time.time() * 1000))
    filename = secure_filename(f.filename)
    saved    = UPLOAD_DIR / f"{uid}_{filename}"
    f.save(str(saved))
    PROGRESS[uid] = []

    def process():
        db = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
        try:
            def log(msg, kind="info"):
                PROGRESS[uid].append({"msg": msg, "kind": kind,
                                       "ts": time.strftime("%H:%M:%S")})

            log(f"File received: {filename}")
            time.sleep(0.3)
            log("Reading file content…")
            text = extract_text(saved, ext)
            time.sleep(0.3)

            if not text.strip():
                log("Could not extract text. Is this a scanned/image PDF?", "error")
                PROGRESS[uid].append({"done": True, "count": 0})
                return

            log(f"Extracted {len(text):,} characters. Parsing Q&A pairs…")
            time.sleep(0.3)
            qs = parse_qa(text)

            if not qs:
                log("No Q&A pairs detected. Check that your file matches one of the supported formats.", "error")
                log("Tip: see the 'Supported formats' panel on the upload page.", "info")
                PROGRESS[uid].append({"done": True, "count": 0})
                return

            log(f"Found {len(qs)} questions. Saving to database…", "ok")
            time.sleep(0.2)

            saved_count = 0
            for i, q in enumerate(qs):
                db.execute(
                    "INSERT INTO questions"
                    "(question, opt_a, opt_b, opt_c, opt_d, answer, category, source)"
                    " VALUES (?,?,?,?,?,?,?,?)",
                    (q["question"], q["opt_a"], q["opt_b"], q["opt_c"],
                     q["opt_d"], q["answer"], q.get("category", "Parsed"), filename)
                )
                db.commit()
                saved_count += 1
                preview = q["question"][:50] + ("…" if len(q["question"]) > 50 else "")
                log(f"Saved Q{i + 1}: {preview}", "ok")
                time.sleep(0.12)

            log(f"Done — {saved_count} questions added to the database.", "ok")
            PROGRESS[uid].append({"done": True, "count": saved_count})
        except Exception as e:
            PROGRESS[uid].append({"msg": f"Error: {e}", "kind": "error"})
            PROGRESS[uid].append({"done": True, "count": 0})
        finally:
            db.close()

    threading.Thread(target=process, daemon=True).start()
    return jsonify({"upload_id": uid, "filename": filename})


@app.route("/admin/upload/progress/<uid>")
@login_required("admin")
def upload_progress(uid):
    logs  = PROGRESS.get(uid, [])
    done  = any(l.get("done") for l in logs)
    count = next((l["count"] for l in logs if l.get("done")), 0)
    return jsonify({
        "logs":  [l for l in logs if "msg" in l],
        "done":  done,
        "count": count,
    })

# ─── questions CRUD ───────────────────────────────────────────────────────────
@app.route("/admin/questions")
@login_required("admin")
def admin_questions():
    db   = get_db()
    rows = db.execute("SELECT * FROM questions ORDER BY id DESC").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/admin/questions/add", methods=["POST"])
@login_required("admin")
def add_question():
    d  = request.json
    db = get_db()
    db.execute(
        "INSERT INTO questions(question, opt_a, opt_b, opt_c, opt_d, answer, category)"
        " VALUES (?,?,?,?,?,?,?)",
        (d["question"], d["opt_a"], d["opt_b"], d["opt_c"],
         d["opt_d"], d["answer"], d.get("category", "Manual"))
    )
    db.commit()
    return jsonify({"ok": True})

@app.route("/admin/questions/delete/<int:qid>", methods=["DELETE"])
@login_required("admin")
def delete_question(qid):
    db = get_db()
    db.execute("DELETE FROM questions WHERE id=?", (qid,))
    db.commit()
    return jsonify({"ok": True})

# ─── users CRUD ───────────────────────────────────────────────────────────────
@app.route("/admin/users")
@login_required("admin")
def admin_users():
    db   = get_db()
    rows = db.execute("SELECT id, username, role FROM users ORDER BY id").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/admin/users/add", methods=["POST"])
@login_required("admin")
def add_user():
    d  = request.json
    db = get_db()
    try:
        db.execute("INSERT INTO users(username, password, role) VALUES (?,?,?)",
                   (d["username"], d["password"], d.get("role", "student")))
        db.commit()
        return jsonify({"ok": True})
    except sqlite3.IntegrityError:
        return jsonify({"error": "Username already exists"}), 409

@app.route("/admin/users/delete/<int:uid>", methods=["DELETE"])
@login_required("admin")
def delete_user(uid):
    db = get_db()
    if uid == session["user_id"]:
        return jsonify({"error": "Cannot delete yourself"}), 400
    db.execute("DELETE FROM users WHERE id=?", (uid,))
    db.commit()
    return jsonify({"ok": True})

@app.route("/admin/users/reset-password", methods=["POST"])
@login_required("admin")
def reset_password():
    d  = request.json
    db = get_db()
    db.execute("UPDATE users SET password=? WHERE id=?", (d["password"], d["user_id"]))
    db.commit()
    return jsonify({"ok": True})

# ─── exam management ──────────────────────────────────────────────────────────
@app.route("/admin/exams")
@login_required("admin")
def admin_exams():
    db   = get_db()
    rows = db.execute("""
        SELECT e.*, u.username AS student_name,
               (SELECT COUNT(*) FROM exam_questions WHERE exam_id = e.id) AS q_count
        FROM exams e
        JOIN users u ON u.id = e.student_id
        ORDER BY e.id DESC
    """).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/admin/exams/create", methods=["POST"])
@login_required("admin")
def create_exam():
    d      = request.json
    db     = get_db()
    cur    = db.execute(
        "INSERT INTO exams(title, student_id, time_limit) VALUES (?,?,?)",
        (d["title"], d["student_id"], d["time_limit"])
    )
    exam_id = cur.lastrowid
    for qid in d["question_ids"]:
        db.execute("INSERT INTO exam_questions(exam_id, question_id) VALUES (?,?)",
                   (exam_id, qid))
    db.commit()
    return jsonify({"ok": True, "exam_id": exam_id})

@app.route("/admin/exams/delete/<int:eid>", methods=["DELETE"])
@login_required("admin")
def delete_exam(eid):
    db = get_db()
    db.execute("DELETE FROM exam_questions WHERE exam_id=?", (eid,))
    db.execute("DELETE FROM exams WHERE id=?", (eid,))
    db.commit()
    return jsonify({"ok": True})

@app.route("/admin/results")
@login_required("admin")
def admin_results():
    db   = get_db()
    rows = db.execute("""
        SELECT r.*, u.username AS student_name, e.title AS exam_title
        FROM results r
        JOIN users u ON u.id = r.student_id
        JOIN exams e ON e.id  = r.exam_id
        ORDER BY r.id DESC
    """).fetchall()
    return jsonify([dict(r) for r in rows])

# ─── student routes ───────────────────────────────────────────────────────────
@app.route("/student")
@login_required("student")
def student_dashboard():
    return render_template("student.html", username=session["username"])

@app.route("/student/exams")
@login_required("student")
def student_exams():
    db   = get_db()
    rows = db.execute("""
        SELECT e.id, e.title, e.time_limit, e.status,
               (SELECT COUNT(*) FROM exam_questions WHERE exam_id = e.id) AS q_count,
               (SELECT id FROM results WHERE exam_id = e.id AND student_id = ?)  AS result_id
        FROM exams e
        WHERE e.student_id = ?
        ORDER BY e.id DESC
    """, (session["user_id"], session["user_id"])).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/student/exam/<int:eid>")
@login_required("student")
def get_exam(eid):
    db  = get_db()
    ex  = db.execute(
        "SELECT * FROM exams WHERE id=? AND student_id=?",
        (eid, session["user_id"])
    ).fetchone()
    if not ex:
        return jsonify({"error": "Exam not found"}), 404
    already = db.execute(
        "SELECT id FROM results WHERE exam_id=? AND student_id=?",
        (eid, session["user_id"])
    ).fetchone()
    if already:
        return jsonify({"error": "Already submitted"}), 409
    rows = db.execute("""
        SELECT q.id, q.question, q.opt_a, q.opt_b, q.opt_c, q.opt_d
        FROM questions q
        JOIN exam_questions eq ON eq.question_id = q.id
        WHERE eq.exam_id = ?
    """, (eid,)).fetchall()
    return jsonify({
        "exam_id":    ex["id"],
        "title":      ex["title"],
        "time_limit": ex["time_limit"],
        "questions":  [dict(r) for r in rows],
    })

@app.route("/student/exam/submit", methods=["POST"])
@login_required("student")
def submit_exam():
    d   = request.json
    db  = get_db()
    eid = d["exam_id"]
    ans = d["answers"]   # {question_id: chosen_option}

    already = db.execute(
        "SELECT id FROM results WHERE exam_id=? AND student_id=?",
        (eid, session["user_id"])
    ).fetchone()
    if already:
        return jsonify({"error": "Already submitted"}), 409

    rows  = db.execute("""
        SELECT q.id, q.answer
        FROM questions q
        JOIN exam_questions eq ON eq.question_id = q.id
        WHERE eq.exam_id = ?
    """, (eid,)).fetchall()
    total = len(rows)
    score = sum(1 for r in rows if ans.get(str(r["id"])) == r["answer"])
    db.execute(
        "INSERT INTO results(exam_id, student_id, score, total, answers)"
        " VALUES (?,?,?,?,?)",
        (eid, session["user_id"], score, total, json.dumps(ans))
    )
    db.execute("UPDATE exams SET status='completed' WHERE id=?", (eid,))
    db.commit()
    return jsonify({"score": score, "total": total})

@app.route("/student/result/<int:eid>")
@login_required("student")
def student_result(eid):
    db  = get_db()
    res = db.execute(
        "SELECT * FROM results WHERE exam_id=? AND student_id=?",
        (eid, session["user_id"])
    ).fetchone()
    if not res:
        return jsonify({"error": "No result found"}), 404
    rows = db.execute("""
        SELECT q.*
        FROM questions q
        JOIN exam_questions eq ON eq.question_id = q.id
        WHERE eq.exam_id = ?
    """, (eid,)).fetchall()
    answers = json.loads(res["answers"])
    review  = []
    for r in rows:
        review.append({
            "question": r["question"],
            "opt_a":    r["opt_a"],
            "opt_b":    r["opt_b"],
            "opt_c":    r["opt_c"],
            "opt_d":    r["opt_d"],
            "correct":  r["answer"],
            "chosen":   answers.get(str(r["id"]), ""),
        })
    return jsonify({"score": res["score"], "total": res["total"], "review": review})

# ─── main ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    print()
    print("=" * 52)
    print("  ExamPortal is running!")
    print("  Open  : http://localhost:5000")
    print("  Admin : admin / admin123")
    print("=" * 52)
    print()
    app.run(debug=True, port=5000)
