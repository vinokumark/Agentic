"""
chainlit_app.py — Chainlit UI for Windows IT Agent

URL resume fix:
  Chainlit's on_chat_start fires for EVERY new browser connection and
  environ/QUERY_STRING is unreliable. The correct approach:

  1. on_chat_start always shows a welcome screen with TWO actions:
       [🆕 New Session]  [🔄 Resume Existing Session]
  2. User clicks Resume → prompted to paste thread ID
  3. Thread ID loaded → history shown immediately
  4. Email link format changed to just show the thread ID clearly,
     user pastes it — no magic URL parsing needed.

  This is 100% reliable across all browsers and Chainlit versions.

Install:  pip install chainlit langgraph-sdk
Run:      chainlit run chainlit_app.py --port 8080

Sidebar history (.env):
    CHAINLIT_AUTH_SECRET=any-random-string
    DATABASE_URL=sqlite:///./chainlit.db
"""

import re
import uuid
import traceback
import chainlit as cl
from langgraph_sdk import get_client
from graph_rag import ingest_file, save_chat_resolution

LANGGRAPH_URL = "http://localhost:2024"
ASSISTANT_ID  = "windows_agent"


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _lg():
    return get_client(url=LANGGRAPH_URL)


async def _stream_agent(thread_id: str, user_message: str) -> str:
    client = _lg()
    final  = ""
    try:
        async for chunk in client.runs.stream(
            thread_id    = thread_id,
            assistant_id = ASSISTANT_ID,
            input        = {"messages": [{"role": "user", "content": user_message}]},
            stream_mode  = "values"
        ):
            if chunk.data and "messages" in chunk.data:
                last    = chunk.data["messages"][-1]
                content = last.get("content", "") if isinstance(last, dict) else getattr(last, "content", "")
                if content:
                    final = content
    except Exception as e:
        print(f"[Chainlit] stream_agent error: {e}")
        traceback.print_exc()
        final = f"Agent error: {e}"
    return final


async def _load_thread_history(thread_id: str) -> list[dict]:
    """
    LangGraph get_state returns a plain dict:
      { "values": { "messages": [...] }, "next": [], ... }
    Access via state["values"]["messages"].
    """
    try:
        client = _lg()
        state  = await client.threads.get_state(thread_id=thread_id)

        if not isinstance(state, dict):
            print(f"[Chainlit] unexpected state type: {type(state)}")
            return []

        channel_values = state.get("values", {})
        if not isinstance(channel_values, dict):
            print(f"[Chainlit] channel_values type: {type(channel_values)}")
            return []

        msgs = channel_values.get("messages", [])
        print(f"[Chainlit] messages found: {len(msgs)}")
        if not msgs:
            return []

        result = []
        for m in msgs:
            if isinstance(m, dict):
                role    = m.get("role", "") or m.get("type", "")
                content = m.get("content", "")
            else:
                role    = getattr(m, "type", None) or getattr(m, "role", "")
                content = getattr(m, "content", "")

            if role == "human":   role = "user"
            elif role in ("ai", "AIMessage"): role = "assistant"

            content = str(content).strip() if content else ""
            if role and content:
                result.append({"role": role, "content": content})

        return result

    except Exception as e:
        print(f"[Chainlit] history load failed: {e}")
        traceback.print_exc()
        return []


def _init_session(thread_id: str, resumed: bool = False):
    cl.user_session.set("thread_id",             thread_id)
    cl.user_session.set("resumed",               resumed)
    cl.user_session.set("issue",                 "")
    cl.user_session.set("last_reply",            "")
    cl.user_session.set("awaiting_save_details", False)
    cl.user_session.set("pending_save",          {})
    cl.user_session.set("awaiting_manual_fix",   False)
    cl.user_session.set("awaiting_thread_id",    False)


async def _show_resolution_actions():
    actions = [
        cl.Action(name="resolved",     label="✅ Issue Resolved — Save Fix",
                  payload={"action": "resolved"},
                  tooltip="Save the resolution to the knowledge base"),
        cl.Action(name="not_resolved", label="🔧 Not Resolved — Give Instructions",
                  payload={"action": "not_resolved"},
                  tooltip="Provide manual fix steps for the agent to execute"),
    ]
    await cl.Message(content="**What is the status of this incident?**",
                     actions=actions).send()


# ══════════════════════════════════════════════════════════════════════════════
# CORE RESUME  (shared by all resume paths)
# ══════════════════════════════════════════════════════════════════════════════

async def _resume_thread(thread_id: str, source: str = "manual"):
    thread_id = thread_id.strip()
    _init_session(thread_id, resumed=True)

    await cl.Message(content=f"🔍 Loading history for `{thread_id}`…").send()

    history   = await _load_thread_history(thread_id)
    msg_count = len(history)

    if history:
        await cl.Message(content=(
            f"## 🔄 Session Resumed\n\n"
            f"**Thread:** `{thread_id}`\n"
            f"**Messages:** {msg_count}\n\n"
            "— Incident history below —"
        )).send()

        for m in history:
            if m["role"] == "user":
                await cl.Message(content=f"👤 **You:** {m['content']}").send()
            elif m["role"] == "assistant":
                await cl.Message(content=f"🤖 **Agent:** {m['content']}").send()

        # Store original issue and last agent reply
        for m in history:
            if m["role"] == "user":
                cl.user_session.set("issue", m["content"][:200])
                break
        for m in reversed(history):
            if m["role"] == "assistant":
                cl.user_session.set("last_reply", m["content"])
                break

        await cl.Message(content=(
            "---\n"
            "Agent has full context. Give your next instruction or use the buttons below."
        )).send()
        await _show_resolution_actions()

    else:
        await cl.Message(content=(
            f"## ⚠️ No History Found\n\n"
            f"Thread `{thread_id}` exists but has no messages yet.\n\n"
            "This could mean the agent hasn't processed the incident yet.\n"
            "You can still send instructions below."
        )).send()


# ══════════════════════════════════════════════════════════════════════════════
# ON CHAT START — always shows welcome with New / Resume choice
# ══════════════════════════════════════════════════════════════════════════════

@cl.on_chat_start
async def on_chat_start():
    """
    Always show welcome screen with two clear options.
    No URL parsing — 100% reliable across all browsers.
    """
    actions = [
        cl.Action(
            name    = "new_session",
            label   = "🆕 Start New Session",
            payload = {"action": "new_session"},
            tooltip = "Start a new incident session"
        ),
        cl.Action(
            name    = "resume_session",
            label   = "🔄 Resume Existing Session",
            payload = {"action": "resume_session"},
            tooltip = "Resume an existing incident by thread ID"
        ),
    ]

    await cl.Message(content=(
        "## 🖥️ Windows & GCP IT Assistant\n\n"
        "What would you like to do?\n\n"
        "- Click **Start New Session** to begin a new incident\n"
        "- Click **Resume Existing Session** to continue from an email link\n\n"
        "📎 You can also upload PDF / Word / TXT files to add to the knowledge base."
    ), actions=actions).send()


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR RESUME  (left sidebar history click)
# ══════════════════════════════════════════════════════════════════════════════

@cl.on_chat_resume
async def on_chat_resume(thread: dict):
    thread_id = thread.get("id") or thread.get("thread_id", "")
    await _resume_thread(thread_id, source="sidebar")


# ══════════════════════════════════════════════════════════════════════════════
# ACTION CALLBACKS
# ══════════════════════════════════════════════════════════════════════════════

@cl.action_callback("new_session")
async def on_new_session(action: cl.Action):
    thread_id = str(uuid.uuid4())
    try:
        await _lg().threads.create(thread_id=thread_id)
        print(f"[Chainlit] new thread: {thread_id}")
    except Exception as e:
        print(f"[Chainlit] thread create failed: {e}")

    _init_session(thread_id)

    await cl.Message(content=(
        "## ✅ New Session Started\n\n"
        f"**Session ID:** `{thread_id}`\n\n"
        "📌 **Save this ID** — you will need it to resume this session.\n"
        "It is also included in any failure emails from the agent.\n\n"
        "---\n"
        "📎 Upload a runbook / doc (PDF / Word / TXT) to add to the knowledge base.\n\n"
        "💬 Describe your issue below to get started."
    )).send()


@cl.action_callback("resume_session")
async def on_resume_session(action: cl.Action):
    cl.user_session.set("awaiting_thread_id", True)

    await cl.Message(content=(
        "🔄 **Resume Session**\n\n"
        "Paste the **Session ID** from your email below.\n\n"
        "It looks like: `5728773a-55b6-496c-96c0-400888502aca`"
    )).send()


@cl.action_callback("resolved")
async def on_resolved(action: cl.Action):
    thread_id  = cl.user_session.get("thread_id")
    issue      = cl.user_session.get("issue", "unknown issue")
    last_reply = cl.user_session.get("last_reply", "")

    cl.user_session.set("pending_save", {
        "resolution": last_reply or f"Incident resolved. Original issue: {issue}",
        "session_id": thread_id,
    })
    cl.user_session.set("awaiting_save_details", True)

    await cl.Message(content=(
        "✅ **Great! Let's save this fix.**\n\n"
        "Reply in this format:\n\n"
        "`topic: Disk Full After Log Rotation | type: command`\n\n"
        "**type:** `command` for step-by-step commands, `info` for process/info"
    )).send()


@cl.action_callback("not_resolved")
async def on_not_resolved(action: cl.Action):
    cl.user_session.set("awaiting_manual_fix", True)

    await cl.Message(content=(
        "🔧 **Provide your manual fix instructions.**\n\n"
        "Type the commands or steps you want the agent to execute.\n"
        "Example: `restart nginx service` or `run df -h on 10.0.0.5`"
    )).send()


# ══════════════════════════════════════════════════════════════════════════════
# INCOMING MESSAGE
# ══════════════════════════════════════════════════════════════════════════════

@cl.on_message
async def on_message(message: cl.Message):
    thread_id = cl.user_session.get("thread_id", "")
    issue     = cl.user_session.get("issue", "")

    # ── File uploads ──────────────────────────────────────────────────────────
    if message.elements:
        for element in message.elements:
            name   = element.name
            suffix = name.lower().rsplit(".", 1)[-1]
            if suffix not in ("pdf", "docx", "doc", "txt"):
                await cl.Message(content=f"⚠️ `{name}` unsupported. Use PDF / Word / TXT.").send()
                continue
            await cl.Message(content=f"📄 Ingesting `{name}`…").send()
            result = ingest_file(element.path, original_name=name)
            await cl.Message(content=result).send()
            if thread_id:
                await _stream_agent(thread_id,
                    f"Document '{name}' added to knowledge base. Acknowledge briefly.")
        if not message.content.strip():
            return

    # ── Waiting for thread ID to resume ───────────────────────────────────────
    if cl.user_session.get("awaiting_thread_id"):
        stripped = message.content.strip()
        # Accept full UUID or extract from text
        uuid_match = re.search(
            r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
            stripped, re.IGNORECASE
        )
        if uuid_match:
            cl.user_session.set("awaiting_thread_id", False)
            await _resume_thread(uuid_match.group(0), source="paste")
        else:
            await cl.Message(content=(
                "⚠️ That doesn't look like a valid Session ID.\n\n"
                "It should look like: `5728773a-55b6-496c-96c0-400888502aca`\n\n"
                "Copy it exactly from your email and paste it here."
            )).send()
        return

    # ── No active session yet ─────────────────────────────────────────────────
    if not thread_id:
        await cl.Message(content=(
            "⚠️ No active session. Please click **Start New Session** or "
            "**Resume Existing Session** above."
        )).send()
        return

    # ── Record first user message as issue ───────────────────────────────────
    if not issue and message.content.strip():
        cl.user_session.set("issue", message.content.strip()[:200])

    content_lower = message.content.lower()

    # ── Save details reply (after ✅ Resolved button) ─────────────────────────
    if cl.user_session.get("awaiting_save_details"):
        pending    = cl.user_session.get("pending_save", {})
        topic      = ""
        entry_type = "INFORMATION_ONLY"

        for part in message.content.strip().split("|"):
            part = part.strip()
            if part.lower().startswith("topic:"):
                topic = part.split(":", 1)[1].strip()
            elif part.lower().startswith("type:"):
                t = part.split(":", 1)[1].strip().lower()
                entry_type = "COMMAND_TASK" if "command" in t else "INFORMATION_ONLY"

        if not topic:
            await cl.Message(
                content="⚠️ Format: `topic: My Fix Title | type: command`"
            ).send()
            return

        rag_result = save_chat_resolution(
            topic      = topic,
            entry_type = entry_type,
            resolution = pending.get("resolution", ""),
            session_id = pending.get("session_id", ""),
        )
        cl.user_session.set("awaiting_save_details", False)
        cl.user_session.set("pending_save", {})
        await cl.Message(content=f"💾 **Saved to knowledge base:**\n\n{rag_result}").send()
        return

    # ── Manual fix (after 🔧 Not Resolved button) ─────────────────────────────
    if cl.user_session.get("awaiting_manual_fix"):
        cl.user_session.set("awaiting_manual_fix", False)

        async with cl.Step(name="Executing manual instructions…") as step:
            reply = await _stream_agent(thread_id, message.content)
            step.output = "Done"

        cl.user_session.set("last_reply", reply)
        await cl.Message(content=reply).send()
        await _show_resolution_actions()
        return

    # ── Inline save keywords ──────────────────────────────────────────────────
    save_triggers = [
        "issue fixed", "save this solution", "save this fix",
        "resolved, save", "fixed, save", "remember this fix",
        "add to knowledge base"
    ]
    if any(t in content_lower for t in save_triggers):
        last_reply = cl.user_session.get("last_reply", "")
        cl.user_session.set("pending_save", {
            "resolution": last_reply or message.content,
            "session_id": thread_id,
        })
        cl.user_session.set("awaiting_save_details", True)
        await cl.Message(content=(
            "💾 **Save to knowledge base**\n\n"
            "Reply: `topic: Your Fix Title | type: command` or `type: info`"
        )).send()
        return

    # ── Normal agent message ──────────────────────────────────────────────────
    async with cl.Step(name="Agent working…") as step:
        reply = await _stream_agent(thread_id, message.content)
        step.output = "Done"

    cl.user_session.set("last_reply", reply)
    await cl.Message(content=reply).send()

    # ── Agent needs human ─────────────────────────────────────────────────────
    if "STATUS: NEEDS_HUMAN" in reply:
        await cl.Message(content=(
            f"⚠️ **Agent could not resolve automatically.**\n\n"
            f"**Session ID:** `{thread_id}`\n\n"
            "Use the buttons below or share this ID to resume from another session."
        )).send()
        await _show_resolution_actions()
