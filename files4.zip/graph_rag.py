"""
graph_rag.py — Shared RAG engine
Used by:  windows_mcp1.py  (tool calls from agent)
          chainlit_app.py  (file upload + session save)

Single source of truth: rag_index/ (FAISS on disk)
No knowledge_base.json — everything lives in the vector index.

Two behaviours fixed here vs earlier version:
  1. Chat saves go into RAG under a proper user-supplied topic,
     not a throwaway session_ key.
  2. Re-uploaded documents are detected via file hash — if content
     changed the index is updated automatically; if unchanged, skipped.

Install:
    pip install langchain langchain-community langchain-huggingface faiss-cpu
    pip install pypdf python-docx sentence-transformers

Model: BAAI/bge-small-en-v1.5
  - Fully local, no API key, ~130MB download on first run
  - Swap EMBED_MODEL for a larger model if needed:
      "BAAI/bge-base-en-v1.5"   (~440MB, better accuracy)
      "BAAI/bge-large-en-v1.5"  (~1.3GB, best accuracy)
"""

import hashlib
import json
from pathlib import Path

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.schema import Document
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

# ── Paths ─────────────────────────────────────────────────────────────────────
FAISS_INDEX_DIR = Path("rag_index")       # FAISS vectors + docstore
DOCS_DIR        = Path("kb_documents")    # uploaded files kept here
HASH_FILE       = Path("rag_index/file_hashes.json")  # tracks file content hashes

EMBED_MODEL = "BAAI/bge-small-en-v1.5"

DOCS_DIR.mkdir(exist_ok=True)

# ── Splitter ──────────────────────────────────────────────────────────────────
splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)

# ── Embeddings — fully local, no API key ──────────────────────────────────────
embeddings = HuggingFaceEmbeddings(
    model_name    = EMBED_MODEL,
    model_kwargs  = {"device": "cpu"},       # change to "cuda" if GPU available
    encode_kwargs = {"normalize_embeddings": True}
)


# ══════════════════════════════════════════════════════════════════════════════
# HASH TRACKER — detects when a re-uploaded file has actually changed
# ══════════════════════════════════════════════════════════════════════════════

def _load_hashes() -> dict:
    if HASH_FILE.exists():
        try:
            return json.loads(HASH_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_hashes(hashes: dict):
    HASH_FILE.parent.mkdir(exist_ok=True)
    HASH_FILE.write_text(json.dumps(hashes, indent=2))


def _file_hash(path: Path) -> str:
    """MD5 of file content — fast enough for runbooks/docs."""
    return hashlib.md5(path.read_bytes()).hexdigest()


def _hash_changed(file_name: str, new_hash: str) -> bool:
    """Returns True if file is new or its content has changed."""
    return _load_hashes().get(file_name) != new_hash


def _update_hash(file_name: str, new_hash: str):
    hashes = _load_hashes()
    hashes[file_name] = new_hash
    _save_hashes(hashes)


def _remove_hash(file_name: str):
    hashes = _load_hashes()
    hashes.pop(file_name, None)
    _save_hashes(hashes)


# ══════════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _make_kb_doc(keyword: str, topic: str, entry_type: str,
                 content_body: str, note: str = "") -> Document:
    """Build a LangChain Document for a KB entry."""
    note_line = f"\nNOTE: {note}" if note else ""
    return Document(
        page_content=f"Topic: {topic}\nType: {entry_type}\n{content_body}{note_line}",
        metadata={
            "keyword": keyword,
            "type":    entry_type,
            "topic":   topic,
            "note":    note,
            "source":  f"kb:{keyword}"    # "kb:" prefix distinguishes KB entries
        }
    )


def _load_file_docs() -> list[Document]:
    """
    Scan kb_documents/ and load every supported file.
    Called only on fresh index build (first run or after manual reset).
    """
    docs = []
    for fp in DOCS_DIR.rglob("*"):
        try:
            if fp.suffix.lower() == ".pdf":
                raw = PyPDFLoader(str(fp)).load()
            elif fp.suffix.lower() in (".docx", ".doc"):
                raw = Docx2txtLoader(str(fp)).load()
            elif fp.suffix.lower() == ".txt":
                raw = [Document(page_content=fp.read_text(), metadata={})]
            else:
                continue
            chunks = splitter.split_documents(raw)
            for c in chunks:
                c.metadata.update({
                    "source": fp.name,
                    "type":   "DOCUMENT",
                    "topic":  fp.stem.replace("_", " ").title()
                })
            docs.extend(chunks)
            print(f"RAG: '{fp.name}' → {len(chunks)} chunks")
        except Exception as e:
            print(f"RAG: failed '{fp.name}': {e}")
    return docs


# ── Delete chunks by source ───────────────────────────────────────────────────
def _delete_by_source(source_value: str) -> int:
    """
    Remove all FAISS chunks where metadata['source'] == source_value.
    Since FAISS has no native delete, we rebuild from remaining docs.
    Works for both file re-uploads and KB entry upserts.
    """
    index    = get_index()
    all_docs = list(index.docstore._dict.values())
    keep     = [d for d in all_docs if d.metadata.get("source") != source_value]
    removed  = len(all_docs) - len(keep)

    if removed == 0:
        return 0

    global _index
    _index = FAISS.from_documents(keep, embeddings) if keep else FAISS.from_documents([
        Document(
            page_content="RAG index initialised.",
            metadata={"type": "SYSTEM", "topic": "Init", "source": "system"}
        )
    ], embeddings)
    _index.save_local(str(FAISS_INDEX_DIR))
    print(f"RAG: removed {removed} chunks for source='{source_value}'")
    return removed


# ══════════════════════════════════════════════════════════════════════════════
# INDEX LIFECYCLE
# ══════════════════════════════════════════════════════════════════════════════

def load_or_build_index() -> FAISS:
    """
    Load persisted FAISS index from rag_index/ if present.
    On first run (or after manual delete), builds from kb_documents/.
    All KB entries saved via save_entry() persist inside the index itself.
    """
    if FAISS_INDEX_DIR.exists():
        try:
            index = FAISS.load_local(
                str(FAISS_INDEX_DIR), embeddings,
                allow_dangerous_deserialization=True
            )
            print(f"RAG: index loaded from {FAISS_INDEX_DIR}")

            # Check if any file in kb_documents/ changed since last run
            _sync_changed_files(index)
            return get_index()   # return after sync (singleton may have updated)
        except Exception as e:
            print(f"RAG: rebuild needed ({e})")

    print("RAG: building fresh index…")
    seed_docs = _load_file_docs()
    if not seed_docs:
        seed_docs = [Document(
            page_content="RAG index initialised. Upload documents or save knowledge entries.",
            metadata={"type": "SYSTEM", "topic": "Init", "source": "system"}
        )]

    index = FAISS.from_documents(seed_docs, embeddings)
    index.save_local(str(FAISS_INDEX_DIR))

    # Record hashes for all files loaded
    for fp in DOCS_DIR.rglob("*"):
        if fp.suffix.lower() in (".pdf", ".docx", ".doc", ".txt"):
            _update_hash(fp.name, _file_hash(fp))

    print(f"RAG: index built from {len(seed_docs)} docs and saved.")
    return index


def _sync_changed_files(index: FAISS):
    """
    On startup, compare every file in kb_documents/ against stored hashes.
    If content changed → delete old chunks and re-index automatically.
    This handles the case where someone manually drops a new version of
    a file into kb_documents/ without going through the UI.
    """
    for fp in DOCS_DIR.rglob("*"):
        if fp.suffix.lower() not in (".pdf", ".docx", ".doc", ".txt"):
            continue
        new_hash = _file_hash(fp)
        if _hash_changed(fp.name, new_hash):
            print(f"RAG: '{fp.name}' changed on disk — re-indexing…")
            ingest_file(str(fp), _skip_copy=True)   # already in DOCS_DIR


# ── Singleton ─────────────────────────────────────────────────────────────────
_index: FAISS | None = None


def get_index() -> FAISS:
    global _index
    if _index is None:
        _index = load_or_build_index()
    return _index


def reload_index():
    """Force full rebuild — wipes index and rebuilds from kb_documents/."""
    global _index
    import shutil
    if FAISS_INDEX_DIR.exists():
        shutil.rmtree(FAISS_INDEX_DIR)
    _index = None
    get_index()


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════════════════

def search(query: str, top_k: int = 3, threshold: float = 1.2) -> list[Document]:
    """Return top_k relevant docs within similarity threshold."""
    results = get_index().similarity_search_with_score(query, k=top_k)
    return [doc for doc, score in results if score <= threshold]


def search_formatted(issue: str) -> str:
    """Formatted result for MCP tool — preserves agent prompt contract."""
    docs = search(issue, top_k=1)

    if not docs:
        return (
            f"TYPE: NOT_FOUND\nTOPIC: {issue}\n"
            "INSTRUCTION: Tell user you don't have information. "
            "Ask them to provide solution so you can save it."
        )

    doc        = docs[0]
    meta       = doc.metadata
    etype      = meta.get("type", "DOCUMENT")
    topic      = meta.get("topic", "")
    note       = meta.get("note", "")
    source     = meta.get("source", "")
    note_sec   = f"\n⚠️  NOTE: {note}" if note else ""
    source_sec = f"\n📄 Source: {source}" if source and not source.startswith("kb:") else ""

    if etype == "INFORMATION_ONLY":
        return (
            f"TYPE: INFORMATION_ONLY\nTOPIC: {topic}{note_sec}{source_sec}\n\n"
            f"{doc.page_content}\n\n"
            "INSTRUCTION: Return this exactly. Tell user say 'ok fix it' to execute.\n"
            + (f"IMPORTANT: {note}" if note else "")
        )
    elif etype == "COMMAND_TASK":
        return (
            f"TYPE: COMMAND_TASK\nTOPIC: {topic}{note_sec}{source_sec}\n\n"
            f"ACTION PLAN:\n{doc.page_content}\n\n"
            "INSTRUCTION: Print plan first, then execute each step with run_command.\n"
            + (f"IMPORTANT: {note}" if note else "")
        )
    else:
        return (
            f"TYPE: DOCUMENT\nTOPIC: {topic}{source_sec}\n\n"
            f"{doc.page_content}\n\n"
            "INSTRUCTION: Use this information to answer the user's question."
        )


def save_entry(
    keyword: str,
    topic: str,
    entry_type: str,
    actions_or_info: str,
    note: str = ""
) -> str:
    """
    Save or update a KB entry directly into the FAISS index.

    - keyword   : short id used for upsert  e.g. 'nginx_restart'
    - topic     : human-readable topic saved AS THE SEARCH TOPIC
                  e.g. 'Nginx Service Restart on Ubuntu'
                  This is what the agent finds when searching — make it descriptive.
    - entry_type: 'COMMAND_TASK' or 'INFORMATION_ONLY'
    - actions_or_info: commands (one per line) or free-text info
    - note      : optional caveat e.g. 'Only for Ubuntu 22.04'

    If keyword already exists the old entry is replaced (upsert).
    """
    kw         = keyword.lower().replace(" ", "_")
    source_key = f"kb:{kw}"

    # Build content body
    if entry_type == "COMMAND_TASK":
        actions = [a.strip() for a in actions_or_info.splitlines() if a.strip()]
        body    = "Actions:\n" + "\n".join(f"  Step {i+1}: {a}" for i, a in enumerate(actions))
    else:
        body = actions_or_info

    # Upsert — delete old, add new
    _delete_by_source(source_key)
    doc = _make_kb_doc(kw, topic, entry_type, body, note)
    get_index().add_documents([doc])
    get_index().save_local(str(FAISS_INDEX_DIR))
    print(f"RAG: upserted KB entry '{kw}' under topic='{topic}'")

    return (
        f"✅ Knowledge saved!\n\n"
        f"Keyword : {kw}\n"
        f"Topic   : {topic}\n"
        f"Type    : {entry_type}\n"
        f"Note    : {note or 'none'}\n\n"
        "Will be retrieved automatically next time a similar issue occurs."
    )


def save_chat_resolution(
    topic: str,
    entry_type: str,
    resolution: str,
    note: str = "",
    session_id: str = ""
) -> str:
    """
    Save a resolution captured from a Chainlit chat session into RAG
    under a PROPER descriptive topic — not a session ID.

    Called by chainlit_app.py when user says 'issue fixed, save this solution'.

    - topic      : descriptive topic the USER or agent provides
                   e.g. 'Apache Not Starting After Config Change'
    - entry_type : 'COMMAND_TASK' or 'INFORMATION_ONLY'
    - resolution : the fix — commands or explanation
    - note       : optional context e.g. 'Tested on prod server 10.0.0.5'
    - session_id : stored in note for traceability but NOT used as the keyword
    """
    # Derive a clean keyword from the topic (not session ID)
    keyword = topic.lower().strip()
    keyword = "".join(c if c.isalnum() or c == " " else " " for c in keyword)
    keyword = "_".join(keyword.split())[:60]   # max 60 chars, snake_case

    full_note = note
    if session_id:
        full_note = f"{note} | session={session_id}".strip(" |")

    return save_entry(
        keyword         = keyword,
        topic           = topic,
        entry_type      = entry_type,
        actions_or_info = resolution,
        note            = full_note
    )


def ingest_file(file_path: str, _skip_copy: bool = False) -> str:
    """
    Load a PDF / DOCX / TXT into the FAISS index.

    Re-upload behaviour:
      - File hash checked against stored hash
      - If UNCHANGED → skipped (no duplicate, fast)
      - If CHANGED   → old chunks deleted, new chunks added, hash updated
      - If NEW       → chunks added, hash stored

    _skip_copy: internal flag used by _sync_changed_files (file already in DOCS_DIR)
    """
    import shutil
    path = Path(file_path)

    if not path.exists():
        return f"❌ File not found: {file_path}"

    suffix   = path.suffix.lower()
    new_hash = _file_hash(path)

    # ── Skip if file content unchanged ───────────────────────────────────────
    if not _hash_changed(path.name, new_hash):
        return f"⏭️ '{path.name}' unchanged — skipped re-index."

    try:
        if suffix == ".pdf":
            raw = PyPDFLoader(str(path)).load()
        elif suffix in (".docx", ".doc"):
            raw = Docx2txtLoader(str(path)).load()
        elif suffix == ".txt":
            raw = [Document(page_content=path.read_text(), metadata={})]
        else:
            return f"❌ Unsupported type '{suffix}'. Use .pdf / .docx / .txt"

        # Delete old chunks for this file
        removed = _delete_by_source(path.name)
        action  = f"replaced {removed} old chunks" if removed else "new file"

        # Chunk and tag with source = filename
        chunks = splitter.split_documents(raw)
        for c in chunks:
            c.metadata.update({
                "source": path.name,
                "type":   "DOCUMENT",
                "topic":  path.stem.replace("_", " ").title()
            })

        get_index().add_documents(chunks)
        get_index().save_local(str(FAISS_INDEX_DIR))

        # Update stored hash
        _update_hash(path.name, new_hash)

        # Copy to kb_documents/ for restart persistence (unless already there)
        if not _skip_copy:
            shutil.copy2(str(path), DOCS_DIR / path.name)

        return f"✅ '{path.name}' ingested — {len(chunks)} chunks added ({action})."
    except Exception as e:
        return f"❌ Ingest failed for '{path.name}': {e}"
