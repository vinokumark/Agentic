"""
windows_mcp1.py — MCP tool server
All knowledge search/save goes through graph_rag.py.
No static KB entries here.

Install:
    pip install mcp paramiko
    pip install langchain langchain-community langchain-huggingface faiss-cpu pypdf python-docx sentence-transformers
"""

from mcp.server.fastmcp import FastMCP
import subprocess
import paramiko
import os

from graph_rag import search_formatted, save_entry, ingest_file

mcp = FastMCP("Windows MCP Server", port=8000)


# ════════════════════════════════════════════════
# TOOL 1 — Search Knowledge Base (RAG)
# ════════════════════════════════════════════════
@mcp.tool()
def search_knowledge_base(issue: str) -> str:
    """
    Semantic search over the RAG knowledge base.
    Use for: GCP, Colt, Striim, disk, memory, network, CPU,
    and any uploaded PDF / Word / TXT documents.
    DO NOT use for person queries.
    """
    print(f"[MCP] search_knowledge_base: '{issue}'")
    return search_formatted(issue)


# ════════════════════════════════════════════════
# TOOL 2 — Save Knowledge
# ════════════════════════════════════════════════
@mcp.tool()
def save_knowledge(
    keyword: str,
    topic: str,
    entry_type: str,
    actions_or_info: str,
    note: str = ""
) -> str:
    """
    Save or update knowledge in the RAG index.

    Use when:
    - User says 'save this solution'
    - User says 'add this to knowledge base'
    - User says 'remember this fix'
    - User says 'ignore this IP', 'decommissioned', 'add a note'

    Parameters:
    - keyword        : short keyword  (e.g. 'nginx_down')
    - topic          : human readable topic
    - entry_type     : 'COMMAND_TASK' or 'INFORMATION_ONLY'
    - actions_or_info: commands (one per line) or info text
    - note           : optional note e.g. 'IGNORE 192.168.1.100 decommissioned'
    """
    print(f"[MCP] save_knowledge: '{keyword}' type={entry_type}")
    return save_entry(keyword, topic, entry_type, actions_or_info, note)


# ════════════════════════════════════════════════
# TOOL 3 — Ingest Document
# ════════════════════════════════════════════════
@mcp.tool()
def ingest_document(file_path: str) -> str:
    """
    Load a PDF, Word (.docx), or TXT file into the RAG knowledge base.
    Use when user says 'add this document', 'load this file',
    'ingest this pdf', 'add this runbook'.

    Parameters:
    - file_path: full or relative path to the file
    """
    print(f"[MCP] ingest_document: '{file_path}'")
    return ingest_file(file_path)


# ════════════════════════════════════════════════
# TOOL 4 — Run Local Command
# ════════════════════════════════════════════════
@mcp.tool()
def run_command(command: str) -> str:
    """
    Execute a shell command on THIS local Windows machine.
    Use for local queries and fix steps.
    For remote machines use ssh_command.
    """
    print(f"[MCP] run_command: '{command}'")
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout if result.stdout else result.stderr


# ════════════════════════════════════════════════
# TOOL 5 — SSH Remote Command
# ════════════════════════════════════════════════
@mcp.tool()
def ssh_command(host: str, command: str) -> str:
    """
    Execute a command on a REMOTE machine via SSH.
    Use when user mentions a specific IP or server name.
    """
    print(f"[MCP] ssh_command {host}: '{command}'")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=host,
            username=os.getenv("SSH_USER", "admin"),
            password=os.getenv("SSH_PASSWORD", ""),
            key_filename=os.getenv("SSH_KEY_PATH", None),
            timeout=10
        )
        _, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode()
        error  = stderr.read().decode()
        client.close()
        return output if output else error
    except Exception as e:
        return f"SSH failed to {host}: {str(e)}"


if __name__ == "__main__":
    mcp.run(transport="sse")
