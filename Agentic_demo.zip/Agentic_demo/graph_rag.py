"""
graph_rag.py — Shared RAG engine
Used by:  windows_mcp1.py  (tool calls from agent)
          chainlit_app.py  (file upload + session save)

Key fixes:
  1. File identity tracked by ORIGINAL filename (not temp path).
     Chainlit passes temp paths like /tmp/tmpXXX.pdf — we extract
     the real name from element.name in chainlit_app.py and pass it here.
  2. _delete_by_source rebuilds index correctly.
  3. No infinite recursion in load_or_build_index.
  4. Hash stored against original filename so re-upload detection works.

Install:
    pip install langchain langchain-community langchain-huggingface faiss-cpu
    pip install pypdf python-docx sentence-transformers
"""

import hashlib
import json
import shutil
from pathlib import Path

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_classic.schema import Document
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_classic.text_splitter import RecursiveCharacterTextSplitter

# ── Paths ─────────────────────────────────────────────────────────────────────
FAISS_INDEX_DIR = Path("rag_index")
DOCS_DIR        = Path("kb_documents")
HASH_FILE       = Path("rag_index/file_hashes.json")

EMBED_MODEL = "BAAI/bge-small-en-v1.5"

DOCS_DIR.mkdir(exist_ok=True)

splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)

embeddings = HuggingFaceEmbeddings(
    model_name    = EMBED_MODEL,
    model_kwargs  = {"device": "cpu"},
    encode_kwargs = {"normalize_embeddings": True}
)

# ── Singleton ─────────────────────────────────────────────────────────────────
_index: FAISS | None = None


# ══════════════════════════════════════════════════════════════════════════════
# HASH TRACKER
# ══════════════════════════════════════════════════════════════════════════════

def _load_hashes() -> dict:
    if HASH_FILE.exists():
        try:
            return json.loads(HASH_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_hashes(hashes: dict):
    HASH_FILE.parent.mkdir(exist_ok=True)
    HASH_FILE.write_text(json.dumps(hashes, indent=2))


def _file_hash(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def _hash_changed(original_name: str, new_hash: str) -> bool:
    """True if file is new or content changed — keyed by ORIGINAL filename."""
    return _load_hashes().get(original_name) != new_hash


def _update_hash(original_name: str, new_hash: str):
    hashes = _load_hashes()
    hashes[original_name] = new_hash
    _save_hashes(hashes)


def _remove_hash(original_name: str):
    hashes = _load_hashes()
    hashes.pop(original_name, None)
    _save_hashes(hashes)


# ══════════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _make_kb_doc(keyword: str, topic: str, entry_type: str,
                 content_body: str, note: str = "") -> Document:
    note_line = f"\nNOTE: {note}" if note else ""
    return Document(
        page_content=f"Topic: {topic}\nType: {entry_type}\n{content_body}{note_line}",
        metadata={
            "keyword": keyword,
            "type":    entry_type,
            "topic":   topic,
            "note":    note,
            "source":  f"kb:{keyword}"
        }
    )


def _load_file_docs() -> list[Document]:
    """Load all files from kb_documents/ — used only on fresh index build."""
    docs = []
    for fp in DOCS_DIR.rglob("*"):
        try:
            if fp.suffix.lower() == ".pdf":
                raw = PyPDFLoader(str(fp)).load()
            elif fp.suffix.lower() in (".docx", ".doc"):
                raw = Docx2txtLoader(str(fp)).load()
            elif fp.suffix.lower() == ".txt":
                raw = [Document(page_content=fp.read_text(), metadata={})]
            else:
                continue
            chunks = splitter.split_documents(raw)
            for c in chunks:
                c.metadata.update({
                    "source": fp.name,   # original filename
                    "type":   "DOCUMENT",
                    "topic":  fp.stem.replace("_", " ").title()
                })
            docs.extend(chunks)
            print(f"RAG: '{fp.name}' → {len(chunks)} chunks")
        except Exception as e:
            print(f"RAG: failed '{fp.name}': {e}")
    return docs


def _delete_by_source(source_value: str) -> int:
    """
    Remove all chunks where metadata['source'] == source_value.
    Rebuilds the entire index without those chunks.
    Returns number of chunks removed.
    """
    global _index
    index    = get_index()
    all_docs = list(index.docstore._dict.values())
    keep     = [d for d in all_docs if d.metadata.get("source") != source_value]
    removed  = len(all_docs) - len(keep)

    if removed == 0:
        print(f"RAG: no chunks found for source='{source_value}'")
        return 0

    # Rebuild without deleted chunks
    if keep:
        _index = FAISS.from_documents(keep, embeddings)
    else:
        _index = FAISS.from_documents([Document(
            page_content="RAG index initialised.",
            metadata={"type": "SYSTEM", "topic": "Init", "source": "system"}
        )], embeddings)

    _index.save_local(str(FAISS_INDEX_DIR))
    print(f"RAG: deleted {removed} chunks for source='{source_value}'")
    return removed


# ══════════════════════════════════════════════════════════════════════════════
# INDEX LIFECYCLE
# ══════════════════════════════════════════════════════════════════════════════

def get_index() -> FAISS:
    global _index
    if _index is None:
        _index = _build_or_load()
    return _index


def _build_or_load() -> FAISS:
    """Load persisted FAISS index or build fresh from kb_documents/."""
    if FAISS_INDEX_DIR.exists():
        try:
            idx = FAISS.load_local(
                str(FAISS_INDEX_DIR), embeddings,
                allow_dangerous_deserialization=True
            )
            print(f"RAG: index loaded — {len(idx.docstore._dict)} chunks")
            return idx
        except Exception as e:
            print(f"RAG: load failed ({e}) — rebuilding")

    print("RAG: building fresh index from kb_documents/…")
    seed_docs = _load_file_docs()
    if not seed_docs:
        seed_docs = [Document(
            page_content="RAG index initialised. Upload documents or save knowledge entries.",
            metadata={"type": "SYSTEM", "topic": "Init", "source": "system"}
        )]

    idx = FAISS.from_documents(seed_docs, embeddings)
    idx.save_local(str(FAISS_INDEX_DIR))

    # Seed hashes
    for fp in DOCS_DIR.rglob("*"):
        if fp.suffix.lower() in (".pdf", ".docx", ".doc", ".txt"):
            _update_hash(fp.name, _file_hash(fp))

    print(f"RAG: fresh index built — {len(seed_docs)} chunks")
    return idx


def reload_index():
    """Force full rebuild — deletes index and rebuilds from kb_documents/."""
    global _index
    if FAISS_INDEX_DIR.exists():
        shutil.rmtree(FAISS_INDEX_DIR)
    _index = None
    get_index()


def sync_changed_files():
    """
    Detect files in kb_documents/ that changed since last run and re-index them.
    Called manually if needed — NOT called automatically on load to avoid recursion.
    """
    for fp in DOCS_DIR.rglob("*"):
        if fp.suffix.lower() not in (".pdf", ".docx", ".doc", ".txt"):
            continue
        new_hash = _file_hash(fp)
        if _hash_changed(fp.name, new_hash):
            print(f"RAG: '{fp.name}' changed — re-indexing")
            ingest_file(str(fp), original_name=fp.name, _skip_copy=True)


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════════════════

def search(query: str, top_k: int = 3, threshold: float = 1.2) -> list[Document]:
    results = get_index().similarity_search_with_score(query, k=top_k)
    return [doc for doc, score in results if score <= threshold]


def search_formatted(issue: str) -> str:
    docs = search(issue, top_k=1)

    if not docs:
        return (
            f"TYPE: NOT_FOUND\nTOPIC: {issue}\n"
            "INSTRUCTION: Tell user you don't have information. "
            "Ask them to provide solution so you can save it."
        )

    doc        = docs[0]
    meta       = doc.metadata
    etype      = meta.get("type", "DOCUMENT")
    topic      = meta.get("topic", "")
    note       = meta.get("note", "")
    source     = meta.get("source", "")
    note_sec   = f"\n⚠️  NOTE: {note}" if note else ""
    source_sec = f"\n📄 Source: {source}" if source and not source.startswith("kb:") else ""

    if etype == "INFORMATION_ONLY":
        return (
            f"TYPE: INFORMATION_ONLY\nTOPIC: {topic}{note_sec}{source_sec}\n\n"
            f"{doc.page_content}\n\n"
            "INSTRUCTION: Return this exactly. Tell user say 'ok fix it' to execute.\n"
            + (f"IMPORTANT: {note}" if note else "")
        )
    elif etype == "COMMAND_TASK":
        return (
            f"TYPE: COMMAND_TASK\nTOPIC: {topic}{note_sec}{source_sec}\n\n"
            f"ACTION PLAN:\n{doc.page_content}\n\n"
            "INSTRUCTION: Print plan first, then execute each step with run_command.\n"
            + (f"IMPORTANT: {note}" if note else "")
        )
    else:
        return (
            f"TYPE: DOCUMENT\nTOPIC: {topic}{source_sec}\n\n"
            f"{doc.page_content}\n\n"
            "INSTRUCTION: Use this information to answer the user's question."
        )


def save_entry(keyword: str, topic: str, entry_type: str,
               actions_or_info: str, note: str = "") -> str:
    kw         = keyword.lower().replace(" ", "_")
    source_key = f"kb:{kw}"

    if entry_type == "COMMAND_TASK":
        actions = [a.strip() for a in actions_or_info.splitlines() if a.strip()]
        body    = "Actions:\n" + "\n".join(f"  Step {i+1}: {a}" for i, a in enumerate(actions))
    else:
        body = actions_or_info

    _delete_by_source(source_key)
    doc = _make_kb_doc(kw, topic, entry_type, body, note)
    get_index().add_documents([doc])
    get_index().save_local(str(FAISS_INDEX_DIR))
    print(f"RAG: upserted '{kw}' topic='{topic}'")

    return (
        f"✅ Knowledge saved!\n\nKeyword : {kw}\nTopic   : {topic}\n"
        f"Type    : {entry_type}\nNote    : {note or 'none'}\n\n"
        "Will be retrieved automatically next time a similar issue occurs."
    )


def save_chat_resolution(topic: str, entry_type: str, resolution: str,
                         note: str = "", session_id: str = "") -> str:
    keyword  = "".join(c if c.isalnum() or c == " " else " " for c in topic.lower().strip())
    keyword  = "_".join(keyword.split())[:60]
    full_note = f"{note} | session={session_id}".strip(" |") if session_id else note
    return save_entry(keyword, topic, entry_type, resolution, full_note)


def ingest_file(file_path: str, original_name: str = "",
                _skip_copy: bool = False) -> str:
    """
    Ingest a file into the FAISS index.

    IMPORTANT — always pass original_name from chainlit element.name.
    Chainlit uploads to a temp path like /tmp/tmpXXXXX.pdf.
    Without original_name, every upload looks like a new file and
    old chunks are never deleted.

    Args:
        file_path     : actual path on disk (may be temp path)
        original_name : original filename e.g. 'runbook.pdf'
                        used as the stable identity for dedup + delete
        _skip_copy    : True when file is already in kb_documents/
    """
    path = Path(file_path)

    if not path.exists():
        return f"❌ File not found: {file_path}"

    # Use original_name as stable identity; fall back to path.name if not given
    stable_name = original_name if original_name else path.name
    suffix      = path.suffix.lower()
    new_hash    = _file_hash(path)

    print(f"RAG: ingest_file stable_name='{stable_name}' hash={new_hash[:8]}")

    # ── Skip if content unchanged ─────────────────────────────────────────────
    if not _hash_changed(stable_name, new_hash):
        print(f"RAG: '{stable_name}' unchanged — skipping")
        return f"⏭️ '{stable_name}' unchanged — skipped re-index."

    try:
        if suffix == ".pdf":
            raw = PyPDFLoader(str(path)).load()
        elif suffix in (".docx", ".doc"):
            raw = Docx2txtLoader(str(path)).load()
        elif suffix == ".txt":
            raw = [Document(page_content=path.read_text(), metadata={})]
        else:
            return f"❌ Unsupported type '{suffix}'. Use .pdf / .docx / .txt"

        # ── Delete old chunks keyed by stable original name ───────────────────
        removed = _delete_by_source(stable_name)
        action  = f"replaced {removed} old chunks" if removed else "new file"

        # ── Chunk and tag with stable_name as source ──────────────────────────
        chunks = splitter.split_documents(raw)
        for c in chunks:
            c.metadata.update({
                "source": stable_name,                          # ← stable name
                "type":   "DOCUMENT",
                "topic":  Path(stable_name).stem.replace("_", " ").title()
            })

        get_index().add_documents(chunks)
        get_index().save_local(str(FAISS_INDEX_DIR))

        # Update hash keyed by stable name
        _update_hash(stable_name, new_hash)

        # Copy to kb_documents/ under original name for restart persistence
        if not _skip_copy:
            dest = DOCS_DIR / stable_name
            shutil.copy2(str(path), dest)
            print(f"RAG: saved to kb_documents/{stable_name}")

        print(f"RAG: '{stable_name}' — {len(chunks)} chunks ({action})")
        return f"✅ '{stable_name}' ingested — {len(chunks)} chunks added ({action})."

    except Exception as e:
        return f"❌ Ingest failed for '{stable_name}': {e}"
