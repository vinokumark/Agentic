"""
chainlit_app.py — Chainlit UI for Windows IT Agent

Fixes vs previous version:
  1. URL resume (?thread=ID) — handled via on_chat_start query params
  2. Left sidebar history — requires data persistence (see .chainlit/config.toml)
  3. Resolved vs Not-Resolved save flow — uses cl.Action buttons, not text parsing
  4. Not-resolved path — user gives manual instructions, agent executes, then saves

Install:
    pip install chainlit langgraph-sdk

Configure (create .chainlit/config.toml):
    [features]
    [features.spontaneous_file_upload]
    enabled = true
    [project]
    enable_telemetry = false

For sidebar history persistence add to .env:
    CHAINLIT_AUTH_SECRET=any-random-string-here
    DATABASE_URL=sqlite:///./chainlit.db

Run:
    chainlit run chainlit_app.py --port 8080
"""

import uuid
import chainlit as cl
from langgraph_sdk import get_client
from graph_rag import ingest_file, save_chat_resolution

LANGGRAPH_URL = "http://localhost:2024"
ASSISTANT_ID  = "windows_agent"
CHAINLIT_PORT = 8080   # must differ from MCP server port 8000


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _lg():
    return get_client(url=LANGGRAPH_URL)


async def _stream_agent(thread_id: str, user_message: str) -> str:
    """Send message to LangGraph agent, return final text reply."""
    client = _lg()
    final  = ""
    async for chunk in client.runs.stream(
        thread_id    = thread_id,
        assistant_id = ASSISTANT_ID,
        input        = {"messages": [{"role": "user", "content": user_message}]},
        stream_mode  = "values"
    ):
        if chunk.data and "messages" in chunk.data:
            last    = chunk.data["messages"][-1]
            content = last.get("content", "") if isinstance(last, dict) else getattr(last, "content", "")
            if content:
                final = content
    return final


async def _load_thread_history(thread_id: str) -> list[dict]:
    """Fetch full message history from LangGraph for a given thread."""
    try:
        client = _lg()
        state  = await client.threads.get_state(thread_id=thread_id)
        msgs   = state.values.get("messages", [])
        result = []
        for m in msgs:
            role    = m.get("role", "")    if isinstance(m, dict) else getattr(m, "role", "")
            content = m.get("content", "") if isinstance(m, dict) else getattr(m, "content", "")
            if role and content:
                result.append({"role": role, "content": content})
        return result
    except Exception as e:
        print(f"[Chainlit] history load failed: {e}")
        return []


def _init_session(thread_id: str, resumed: bool = False):
    """Set all session keys to clean defaults."""
    cl.user_session.set("thread_id",              thread_id)
    cl.user_session.set("resumed",                resumed)
    cl.user_session.set("issue",                  "")
    cl.user_session.set("last_reply",             "")
    cl.user_session.set("awaiting_save_details",  False)
    cl.user_session.set("pending_save",           {})
    cl.user_session.set("awaiting_manual_fix",    False)


# ══════════════════════════════════════════════════════════════════════════════
# NEW SESSION  (also handles ?thread=ID URL resume)
# ══════════════════════════════════════════════════════════════════════════════
@cl.on_chat_start
async def on_chat_start():
    # ── Check if URL contains ?thread=<id> ───────────────────────────────────
    # Chainlit exposes query params via cl.context.session.client_type / metadata
    # The standard way is reading from the browser URL via cl.context
    # Read ?thread=ID from ASGI environ query string
    url_thread = ""
    try:
        environ      = getattr(cl.context.session, "environ", {}) or {}
        query_string = environ.get("QUERY_STRING", "") or ""
        if isinstance(query_string, bytes):
            query_string = query_string.decode("utf-8")
        for part in query_string.split("&"):
            if part.startswith("thread="):
                url_thread = part.split("=", 1)[1].strip()
                break
    except Exception as e:
        print(f"[Chainlit] query param read error: {e}")

    if url_thread:
        # ── Resume from URL ───────────────────────────────────────────────────
        await _resume_thread(url_thread, source="url")
    else:
        # ── Brand new session ─────────────────────────────────────────────────
        thread_id = str(uuid.uuid4())
        try:
            await _lg().threads.create(thread_id=thread_id)
        except Exception as e:
            print(f"[Chainlit] thread create failed: {e}")

        _init_session(thread_id)

        await cl.Message(content=(
            "## 🖥️ Windows & GCP IT Assistant\n\n"
            f"**Session ID:** `{thread_id}`\n\n"
            "📌 Copy and save this ID — paste it here or use the link in the failure "
            "email to resume this conversation at any time.\n\n"
            "---\n"
            "📎 **Upload a runbook / doc** (PDF / Word / TXT) using the attachment "
            "button to add it to the knowledge base.\n\n"
            "💬 **Describe your issue** below to get started."
        )).send()


# ══════════════════════════════════════════════════════════════════════════════
# RESUME SESSION  (called by Chainlit sidebar click OR programmatically)
# ══════════════════════════════════════════════════════════════════════════════
@cl.on_chat_resume
async def on_chat_resume(thread: dict):
    """
    Called when user clicks a past conversation in the left sidebar.
    Chainlit passes the stored thread dict.
    """
    thread_id = thread.get("id") or thread.get("thread_id", "")
    await _resume_thread(thread_id, source="sidebar")


async def _resume_thread(thread_id: str, source: str = "manual"):
    """
    Core resume logic — shared by URL resume, sidebar resume, and paste resume.
    Loads history from LangGraph and replays it in the Chainlit UI.
    """
    _init_session(thread_id, resumed=True)

    history   = await _load_thread_history(thread_id)
    msg_count = len(history)

    # ── Replay history so user sees full incident in the chat window ──────────
    if history:
        await cl.Message(content=(
            f"## 🔄 Session Resumed ({source})\n\n"
            f"**Thread:** `{thread_id}`\n"
            f"**Messages:** {msg_count}\n\n"
            "— Full incident history below —"
        )).send()

        for m in history:
            role    = m["role"]
            content = m["content"]
            if role == "user":
                # Show user messages as plain info (already in sidebar)
                await cl.Message(content=f"👤 **You:** {content}").send()
            elif role == "assistant":
                await cl.Message(content=f"🤖 **Agent:** {content}").send()

        # Store first user message as the issue
        for m in history:
            if m["role"] == "user":
                cl.user_session.set("issue", m["content"][:200])
                break
    else:
        await cl.Message(content=(
            f"## 🔄 Session Resumed\n\n"
            f"**Thread:** `{thread_id}`\n"
            "No history found — this may be a new or empty thread."
        )).send()

    await cl.Message(content=(
        "---\n"
        "The agent has full context of this incident.\n\n"
        "💬 Give your next instruction — or use the buttons below if resolved."
    )).send()

    # Show resolved / not-resolved action buttons
    await _show_resolution_actions()


async def _show_resolution_actions():
    """Show Resolved / Not Resolved action buttons."""
    actions = [
        cl.Action(
            name    = "resolved",
            label   = "✅ Issue Resolved — Save Fix",
            payload = {"action": "resolved"},
            tooltip = "Save the resolution to the knowledge base"
        ),
        cl.Action(
            name    = "not_resolved",
            label   = "🔧 Not Resolved — Give Instructions",
            payload = {"action": "not_resolved"},
            tooltip = "Provide manual fix steps for the agent to execute"
        ),
    ]
    await cl.Message(
        content = "**What is the status of this incident?**",
        actions = actions
    ).send()


# ══════════════════════════════════════════════════════════════════════════════
# ACTION HANDLERS  (button clicks)
# ══════════════════════════════════════════════════════════════════════════════
@cl.action_callback("resolved")
async def on_resolved(action: cl.Action):
    """User clicked 'Issue Resolved' — ask for topic and save to RAG."""
    thread_id = cl.user_session.get("thread_id")
    issue     = cl.user_session.get("issue", "unknown issue")
    last_reply= cl.user_session.get("last_reply", "")

    cl.user_session.set("pending_save", {
        "resolution": last_reply or f"Incident resolved. Original issue: {issue}",
        "session_id": thread_id,
    })
    cl.user_session.set("awaiting_save_details", True)

    await cl.Message(content=(
        "✅ **Great! Let's save this fix to the knowledge base.**\n\n"
        "Reply with the topic and type in this format:\n\n"
        "`topic: Disk Full After Log Rotation | type: command`\n\n"
        "**type** options:\n"
        "- `command` — fix involved running commands\n"
        "- `info`    — fix was informational / process-based"
    )).send()


@cl.action_callback("not_resolved")
async def on_not_resolved(action: cl.Action):
    """User clicked 'Not Resolved' — ask for manual instructions."""
    cl.user_session.set("awaiting_manual_fix", True)

    await cl.Message(content=(
        "🔧 **Provide your manual fix instructions.**\n\n"
        "Type the commands or steps you want the agent to execute.\n"
        "The agent will run them and report back.\n\n"
        "Example:\n"
        "`run: df -h` then `run: rm -rf /var/log/old_logs`\n\n"
        "Or just describe what to do in plain English."
    )).send()


# ══════════════════════════════════════════════════════════════════════════════
# INCOMING MESSAGE
# ══════════════════════════════════════════════════════════════════════════════
@cl.on_message
async def on_message(message: cl.Message):
    thread_id = cl.user_session.get("thread_id")
    issue     = cl.user_session.get("issue", "")

    # ── Handle file uploads ───────────────────────────────────────────────────
    if message.elements:
        for element in message.elements:
            name   = element.name
            suffix = name.lower().rsplit(".", 1)[-1]
            if suffix not in ("pdf", "docx", "doc", "txt"):
                await cl.Message(
                    content=f"⚠️ `{name}` — unsupported. Use PDF / Word / TXT."
                ).send()
                continue
            await cl.Message(content=f"📄 Ingesting `{name}`…").send()
            result = ingest_file(element.path)
            await cl.Message(content=result).send()
            await _stream_agent(
                thread_id,
                f"Document '{name}' added to knowledge base. Acknowledge briefly."
            )
        if not message.content.strip():
            return

    # ── Save first user message as the issue ─────────────────────────────────
    if not issue and message.content.strip():
        cl.user_session.set("issue", message.content.strip()[:200])

    content_lower = message.content.lower()

    # ── Handle paste of a thread/session ID ──────────────────────────────────
    # Detect UUID pattern pasted into chat
    import re
    uuid_pattern = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    uuid_match   = re.search(uuid_pattern, message.content.strip(), re.IGNORECASE)
    if uuid_match and len(message.content.strip()) < 50:
        pasted_id = uuid_match.group(0)
        await cl.Message(content=f"🔍 Detected session ID `{pasted_id}` — loading history…").send()
        await _resume_thread(pasted_id, source="paste")
        return

    # ── Handle save details reply (after resolved button) ────────────────────
    if cl.user_session.get("awaiting_save_details"):
        pending = cl.user_session.get("pending_save", {})
        content = message.content.strip()

        topic      = ""
        entry_type = "INFORMATION_ONLY"
        for part in content.split("|"):
            part = part.strip()
            if part.lower().startswith("topic:"):
                topic = part.split(":", 1)[1].strip()
            elif part.lower().startswith("type:"):
                t = part.split(":", 1)[1].strip().lower()
                entry_type = "COMMAND_TASK" if "command" in t else "INFORMATION_ONLY"

        if not topic:
            await cl.Message(
                content="⚠️ Could not parse. Format: `topic: My Fix Title | type: command`"
            ).send()
            return

        rag_result = save_chat_resolution(
            topic           = topic,
            entry_type      = entry_type,
            resolution      = pending.get("resolution", ""),
            session_id      = pending.get("session_id", ""),
        )
        cl.user_session.set("awaiting_save_details", False)
        cl.user_session.set("pending_save", {})
        await cl.Message(content=f"💾 **Saved to knowledge base:**\n\n{rag_result}").send()
        return

    # ── Handle manual fix instructions (after not-resolved button) ───────────
    if cl.user_session.get("awaiting_manual_fix"):
        cl.user_session.set("awaiting_manual_fix", False)

        async with cl.Step(name="Executing manual instructions…") as step:
            reply = await _stream_agent(thread_id, message.content)
            step.output = "Done"

        cl.user_session.set("last_reply", reply)
        await cl.Message(content=reply).send()

        # After manual execution — ask status again
        await _show_resolution_actions()
        return

    # ── Detect inline save trigger keywords ──────────────────────────────────
    save_triggers = [
        "issue fixed", "save this solution", "save this fix",
        "resolved, save", "fixed, save", "remember this fix",
        "add to knowledge base"
    ]
    if any(t in content_lower for t in save_triggers):
        last_reply = cl.user_session.get("last_reply", "")
        cl.user_session.set("pending_save", {
            "resolution": last_reply or message.content,
            "session_id": thread_id,
        })
        cl.user_session.set("awaiting_save_details", True)
        await cl.Message(content=(
            "💾 **Save to knowledge base**\n\n"
            "Reply: `topic: Your Fix Title | type: command` or `type: info`"
        )).send()
        return

    # ── Normal agent message ──────────────────────────────────────────────────
    async with cl.Step(name="Agent working…") as step:
        reply = await _stream_agent(thread_id, message.content)
        step.output = "Done"

    cl.user_session.set("last_reply", reply)
    await cl.Message(content=reply).send()

    # ── If agent signals needs human — show action buttons ───────────────────
    if "STATUS: NEEDS_HUMAN" in reply:
        await cl.Message(content=(
            f"⚠️ **Agent could not resolve automatically.**\n\n"
            f"**Session ID:** `{thread_id}`\n\n"
            "Use the buttons below or paste this ID in a new session to resume."
        )).send()
        await _show_resolution_actions()
