"""
chainlit_app.py — Chainlit UI for Windows IT Agent
Features:
  - File upload (PDF / DOCX / TXT) → ingested into RAG
  - New session: fresh conversation with new thread_id
  - Resume session: paste existing thread_id to rejoin incident
  - After manual fix: save resolution into RAG automatically

Install:
    pip install chainlit langgraph-sdk
Run:
    chainlit run chainlit_app.py
"""

import chainlit as cl
from langgraph_sdk import get_client
from graph_rag import ingest_file, save_session_resolution, search

LANGGRAPH_URL  = "http://localhost:2024"
ASSISTANT_ID   = "windows_agent"


# ── Helpers ───────────────────────────────────────────────────────────────────
def _lg_client():
    return get_client(url=LANGGRAPH_URL)


async def _stream_agent(thread_id: str, user_message: str) -> str:
    """Send a message to the LangGraph agent and return the final reply."""
    client = _lg_client()
    final  = ""
    async for chunk in client.runs.stream(
        thread_id    = thread_id,
        assistant_id = ASSISTANT_ID,
        input        = {"messages": [{"role": "user", "content": user_message}]},
        stream_mode  = "values"
    ):
        if chunk.data and "messages" in chunk.data:
            last = chunk.data["messages"][-1]
            # last may be dict (streaming) or object
            content = last.get("content", "") if isinstance(last, dict) else getattr(last, "content", "")
            if content:
                final = content
    return final


# ════════════════════════════════════════════════
# NEW SESSION
# ════════════════════════════════════════════════
@cl.on_chat_start
async def on_chat_start():
    import uuid
    thread_id = str(uuid.uuid4())
    client    = _lg_client()
    await client.threads.create(thread_id=thread_id)

    cl.user_session.set("thread_id", thread_id)
    cl.user_session.set("issue",     "")          # will be set on first message
    cl.user_session.set("resumed",   False)

    await cl.Message(content=(
        "## 🖥️ Windows & GCP IT Assistant\n\n"
        f"**Session ID:** `{thread_id}`\n\n"
        "Save this ID — paste it at any time to resume this conversation.\n\n"
        "---\n"
        "📎 **Upload a runbook or doc** (PDF / Word / TXT) using the attachment button "
        "to add it to the knowledge base.\n\n"
        "💬 Or just describe your issue below."
    )).send()


# ════════════════════════════════════════════════
# RESUME SESSION
# ════════════════════════════════════════════════
@cl.on_chat_resume
async def on_chat_resume(thread):
    thread_id = thread["id"]
    client    = _lg_client()

    cl.user_session.set("thread_id", thread_id)
    cl.user_session.set("resumed",   True)
    cl.user_session.set("issue",     "")

    # Try to pull previous messages to show context
    try:
        state = await client.threads.get_state(thread_id=thread_id)
        msgs  = state.values.get("messages", [])
        # Find the original issue from first user message
        for m in msgs:
            content = m.get("content", "") if isinstance(m, dict) else getattr(m, "content", "")
            role    = m.get("role", "")    if isinstance(m, dict) else getattr(m, "role", "")
            if role == "user" and content:
                cl.user_session.set("issue", content[:200])
                break
        msg_count = len(msgs)
    except Exception:
        msg_count = 0

    await cl.Message(content=(
        f"## 🔄 Session Resumed\n\n"
        f"**Thread ID:** `{thread_id}`\n"
        f"**Messages in history:** {msg_count}\n\n"
        "The agent has full context of this incident.\n\n"
        "Tell me what to try next — or say **'issue fixed, save this solution'** "
        "once it's resolved."
    )).send()


# ════════════════════════════════════════════════
# INCOMING MESSAGE
# ════════════════════════════════════════════════
@cl.on_message
async def on_message(message: cl.Message):
    thread_id = cl.user_session.get("thread_id")
    issue     = cl.user_session.get("issue", "")

    # ── Handle file uploads ───────────────────────────────────────────────────
    if message.elements:
        for element in message.elements:
            name   = element.name
            suffix = name.lower().split(".")[-1]

            if suffix not in ("pdf", "docx", "doc", "txt"):
                await cl.Message(
                    content=f"⚠️ `{name}` — unsupported type. Please upload PDF, Word, or TXT."
                ).send()
                continue

            processing = await cl.Message(content=f"📄 Ingesting `{name}`…").send()
            result     = ingest_file(element.path)
            await cl.Message(content=result).send()

            # Also tell the agent so it knows a new doc is available
            await _stream_agent(
                thread_id,
                f"A new document '{name}' has been added to the knowledge base. "
                "Acknowledge this briefly."
            )
        # If message also has text, fall through; otherwise return
        if not message.content.strip():
            return

    # ── Save first message as the issue description ───────────────────────────
    if not issue and message.content.strip():
        cl.user_session.set("issue", message.content.strip()[:200])

    # ── Detect "save this solution" intent ───────────────────────────────────
    content_lower = message.content.lower()
    save_triggers = [
        "issue fixed", "save this solution", "save this fix",
        "resolved, save", "fixed, save", "remember this fix",
        "add to knowledge base"
    ]
    wants_save = any(t in content_lower for t in save_triggers)

    # ── Show typing indicator ─────────────────────────────────────────────────
    async with cl.Step(name="Agent working…") as step:
        reply = await _stream_agent(thread_id, message.content)
        step.output = "Done"

    await cl.Message(content=reply).send()

    # ── Auto-save to RAG if user confirmed fix ────────────────────────────────
    if wants_save:
        saved_issue = cl.user_session.get("issue", "unknown issue")
        rag_result  = save_session_resolution(
            session_id = thread_id,
            issue      = saved_issue,
            resolution = f"User message: {message.content}\n\nAgent response: {reply}"
        )
        await cl.Message(content=f"💾 **Saved to knowledge base:**\n{rag_result}").send()

    # ── Offer save if agent says NEEDS_HUMAN and session was autonomous ───────
    if "STATUS: NEEDS_HUMAN" in reply and not cl.user_session.get("resumed"):
        await cl.Message(content=(
            "⚠️ **Agent could not resolve this automatically.**\n\n"
            f"**Session ID:** `{thread_id}`\n\n"
            "You can:\n"
            "- Give manual instructions here and I'll execute them\n"
            "- Come back later: paste the Session ID above to resume\n"
            "- Once fixed, say **'issue fixed, save this solution'** to teach me for next time"
        )).send()


# ════════════════════════════════════════════════
# SETTINGS — shown in sidebar
# ════════════════════════════════════════════════
@cl.on_settings_update
async def on_settings(settings):
    pass  # reserved for future config (model choice, top_k, etc.)
