"""
graph_rag.py — Shared RAG engine
Used by:  windows_mcp1.py  (tool calls from agent)
          chainlit_app.py  (file upload + session save)

Install:
    pip install langchain langchain-community langchain-huggingface faiss-cpu
    pip install pypdf python-docx sentence-transformers
    (no Ollama needed — embeddings run locally via HuggingFace)

Model used: BAAI/bge-small-en-v1.5
  - Free, fully local, no API key
  - ~130MB download on first run
  - Strong performance on retrieval tasks (MTEB top tier for its size)
  - Swap EMBED_MODEL below for a larger model if needed:
      "BAAI/bge-base-en-v1.5"   (~440MB, better accuracy)
      "BAAI/bge-large-en-v1.5"  (~1.3GB, best accuracy)
      "sentence-transformers/all-MiniLM-L6-v2"  (lightweight alternative)
"""

import json
from pathlib import Path
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.schema import Document
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

# ── Paths ─────────────────────────────────────────────────────────────────────
FAISS_INDEX_DIR = Path("rag_index")
KB_JSON_FILE    = Path("knowledge_base.json")
DOCS_DIR        = Path("kb_documents")

# ── Embedding model ───────────────────────────────────────────────────────────
# Runs fully local — downloads once from HuggingFace Hub, cached in ~/.cache
EMBED_MODEL = "BAAI/bge-small-en-v1.5"

DOCS_DIR.mkdir(exist_ok=True)

# ── Splitter ──────────────────────────────────────────────────────────────────
splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)

# ── Embeddings ────────────────────────────────────────────────────────────────
# encode_kwargs: normalise vectors so cosine similarity works correctly with FAISS
embeddings = HuggingFaceEmbeddings(
    model_name   = EMBED_MODEL,
    model_kwargs = {"device": "cpu"},          # change to "cuda" if GPU available
    encode_kwargs= {"normalize_embeddings": True}
)


# ── Internal helpers ──────────────────────────────────────────────────────────
def _entry_to_doc(keyword: str, entry: dict) -> Document | None:
    etype = entry.get("type", "")
    topic = entry.get("topic", keyword)
    note  = entry.get("note", "")

    if etype == "COMMAND_TASK":
        actions = entry.get("actions", [])
        steps   = "\n".join(f"  Step {i+1}: {a}" for i, a in enumerate(actions))
        content = f"Topic: {topic}\nType: COMMAND_TASK\nActions:\n{steps}"
    elif etype == "INFORMATION_ONLY":
        content = f"Topic: {topic}\nType: INFORMATION_ONLY\n{entry.get('info', '')}"
    else:
        return None

    if note:
        content += f"\nNOTE: {note}"

    return Document(
        page_content=content,
        metadata={"keyword": keyword, "type": etype, "topic": topic, "note": note}
    )


def _load_saved_kb() -> list[Document]:
    docs = []
    if KB_JSON_FILE.exists():
        try:
            saved = json.loads(KB_JSON_FILE.read_text())
            for kw, entry in saved.items():
                doc = _entry_to_doc(kw, entry)
                if doc:
                    docs.append(doc)
            print(f"RAG: {len(docs)} KB entries loaded from {KB_JSON_FILE}")
        except Exception as e:
            print(f"RAG: KB load error: {e}")
    return docs


def _load_file_docs() -> list[Document]:
    docs = []
    for fp in DOCS_DIR.rglob("*"):
        try:
            if fp.suffix.lower() == ".pdf":
                raw = PyPDFLoader(str(fp)).load()
            elif fp.suffix.lower() in (".docx", ".doc"):
                raw = Docx2txtLoader(str(fp)).load()
            elif fp.suffix.lower() == ".txt":
                raw = [Document(page_content=fp.read_text(), metadata={})]
            else:
                continue
            chunks = splitter.split_documents(raw)
            for c in chunks:
                c.metadata.update({
                    "source": fp.name,
                    "type":   "DOCUMENT",
                    "topic":  fp.stem.replace("_", " ").title()
                })
            docs.extend(chunks)
            print(f"RAG: '{fp.name}' → {len(chunks)} chunks")
        except Exception as e:
            print(f"RAG: failed '{fp.name}': {e}")
    return docs


# ── Build or load FAISS index ─────────────────────────────────────────────────
def load_or_build_index() -> FAISS:
    all_docs = _load_saved_kb() + _load_file_docs()

    if not all_docs:
        # Seed with a placeholder so FAISS doesn't fail on empty corpus
        all_docs = [Document(
            page_content="RAG index initialised. Add documents or save knowledge entries.",
            metadata={"type": "SYSTEM", "topic": "Init"}
        )]

    if FAISS_INDEX_DIR.exists():
        try:
            index = FAISS.load_local(
                str(FAISS_INDEX_DIR), embeddings,
                allow_dangerous_deserialization=True
            )
            print(f"RAG: index loaded from {FAISS_INDEX_DIR}")
            return index
        except Exception as e:
            print(f"RAG: rebuild needed ({e})")

    print(f"RAG: building index from {len(all_docs)} docs…")
    index = FAISS.from_documents(all_docs, embeddings)
    index.save_local(str(FAISS_INDEX_DIR))
    print("RAG: index saved.")
    return index


# Singleton — imported by both mcp server and chainlit app
_index: FAISS | None = None


def get_index() -> FAISS:
    global _index
    if _index is None:
        _index = load_or_build_index()
    return _index


def reload_index():
    """Force rebuild — call after adding new files to DOCS_DIR."""
    global _index
    import shutil
    if FAISS_INDEX_DIR.exists():
        shutil.rmtree(FAISS_INDEX_DIR)
    _index = load_or_build_index()


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API — used by MCP tools and Chainlit
# ══════════════════════════════════════════════════════════════════════════════

def search(query: str, top_k: int = 3, threshold: float = 1.2) -> list[Document]:
    """Return top_k relevant docs above similarity threshold."""
    results = get_index().similarity_search_with_score(query, k=top_k)
    return [doc for doc, score in results if score <= threshold]


def search_formatted(issue: str) -> str:
    """
    Formatted string for MCP tool — preserves agent prompt contract.
    Returns TYPE / TOPIC / ACTION PLAN or INFORMATION block.
    """
    docs = search(issue, top_k=1)

    if not docs:
        return (
            f"TYPE: NOT_FOUND\nTOPIC: {issue}\n"
            "INSTRUCTION: Tell user you don't have information. "
            "Ask them to provide solution so you can save it."
        )

    doc    = docs[0]
    meta   = doc.metadata
    etype  = meta.get("type", "DOCUMENT")
    topic  = meta.get("topic", "")
    note   = meta.get("note", "")
    source = meta.get("source", "")

    note_sec   = f"\n⚠️  NOTE: {note}" if note else ""
    source_sec = f"\n📄 Source: {source}" if source else ""

    if etype == "INFORMATION_ONLY":
        return (
            f"TYPE: INFORMATION_ONLY\nTOPIC: {topic}{note_sec}{source_sec}\n\n"
            f"{doc.page_content}\n\n"
            "INSTRUCTION: Return this exactly. Tell user say 'ok fix it' to execute.\n"
            + (f"IMPORTANT: {note}" if note else "")
        )
    elif etype == "COMMAND_TASK":
        return (
            f"TYPE: COMMAND_TASK\nTOPIC: {topic}{note_sec}{source_sec}\n\n"
            f"ACTION PLAN:\n{doc.page_content}\n\n"
            "INSTRUCTION: Print plan first, then execute each step with run_command.\n"
            + (f"IMPORTANT: {note}" if note else "")
        )
    else:
        return (
            f"TYPE: DOCUMENT\nTOPIC: {topic}{source_sec}\n\n"
            f"{doc.page_content}\n\n"
            "INSTRUCTION: Use this information to answer the user's question."
        )


def save_entry(
    keyword: str,
    topic: str,
    entry_type: str,
    actions_or_info: str,
    note: str = ""
) -> str:
    """Save a KB entry to JSON + live FAISS index."""
    kw = keyword.lower().replace(" ", "_")

    if entry_type == "COMMAND_TASK":
        actions = [a.strip() for a in actions_or_info.splitlines() if a.strip()]
        entry   = {"type": "COMMAND_TASK", "topic": topic, "actions": actions}
    else:
        entry   = {"type": "INFORMATION_ONLY", "topic": topic, "info": actions_or_info}

    if note:
        entry["note"] = note

    # Persist JSON
    saved = {}
    if KB_JSON_FILE.exists():
        try:
            saved = json.loads(KB_JSON_FILE.read_text())
        except Exception:
            pass
    saved[kw] = entry
    KB_JSON_FILE.write_text(json.dumps(saved, indent=2))

    # Update live index
    doc = _entry_to_doc(kw, entry)
    if doc:
        get_index().add_documents([doc])
        get_index().save_local(str(FAISS_INDEX_DIR))
        print(f"RAG: saved '{kw}' to index")

    return (
        f"Knowledge saved!\n\nKeyword : {kw}\nTopic   : {topic}\n"
        f"Type    : {entry_type}\nNote    : {note or 'none'}\n\n"
        "Will be used automatically next time a similar issue occurs."
    )


def ingest_file(file_path: str) -> str:
    """Load a PDF / DOCX / TXT file into the live FAISS index."""
    import shutil
    path = Path(file_path)

    if not path.exists():
        return f"❌ File not found: {file_path}"

    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            raw = PyPDFLoader(str(path)).load()
        elif suffix in (".docx", ".doc"):
            raw = Docx2txtLoader(str(path)).load()
        elif suffix == ".txt":
            raw = [Document(page_content=path.read_text(), metadata={})]
        else:
            return f"❌ Unsupported type '{suffix}'. Use .pdf / .docx / .txt"

        chunks = splitter.split_documents(raw)
        for c in chunks:
            c.metadata.update({
                "source": path.name,
                "type":   "DOCUMENT",
                "topic":  path.stem.replace("_", " ").title()
            })

        get_index().add_documents(chunks)
        get_index().save_local(str(FAISS_INDEX_DIR))

        # Copy to kb_documents for persistence across restarts
        dest = DOCS_DIR / path.name
        if not dest.exists():
            shutil.copy2(str(path), str(dest))

        return f"✅ '{path.name}' ingested — {len(chunks)} chunks added."
    except Exception as e:
        return f"❌ Ingest failed for '{path.name}': {e}"


def save_session_resolution(session_id: str, issue: str, resolution: str) -> str:
    """
    Save a human-provided resolution from Chainlit session into RAG.
    Called when user fixes an incident manually and we want to remember the fix.
    """
    keyword = f"session_{session_id[:8]}"
    topic   = f"Manual fix: {issue[:80]}"
    return save_entry(
        keyword=keyword,
        topic=topic,
        entry_type="INFORMATION_ONLY",
        actions_or_info=resolution,
        note=f"Manually resolved via session {session_id}"
    )
