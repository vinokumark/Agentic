ExamPortal
==========

A simple exam management system built with Python + Flask.

QUICK START
-----------
1. Install dependencies (one time only):
      pip install flask pypdf python-docx

2. Run the app:
      python app.py

3. Open in your browser:
      http://localhost:5000

Default admin login:  admin / admin123


PROJECT STRUCTURE
-----------------
  app.py               Main application (routes, DB, parser)
  examportal.db        SQLite database (auto-created on first run)
  uploads/             Uploaded files are stored here
  templates/
    login.html         Login page
    admin.html         Admin panel
    student.html       Student exam page


ADMIN WORKFLOW
--------------
1. Log in as admin
2. Go to "Upload Q&A" — upload a PDF, DOCX, or TXT file
3. Watch the live progress log as questions are saved to the DB
4. Go to "Users" — create student accounts (set username + password)
5. Go to "Assign Exams" — pick a student, select questions, set time limit
6. Go to "Results" to view submitted scores


STUDENT WORKFLOW
----------------
1. Log in with credentials the admin set
2. See assigned exams on the dashboard
3. Click "Start exam" — a countdown timer runs
4. Choose A/B/C/D for each question
5. Submit — instantly see score with correct/wrong answers highlighted


SUPPORTED FILE FORMATS
-----------------------
The parser detects these Q&A layouts automatically:

  Format A (inline options):
    Q1. Question text?
    A) opt   B) opt   C) opt   D) opt
    Answer: B

  Format B (separate lines):
    1. Question text?
    a. opt
    b. opt
    c. opt
    d. opt
    Answer: b

  Format C (Question: label):
    Question: Question text?
    A: opt
    B: opt
    C: opt
    D: opt
    Correct Answer: A

  Format D (parenthesised):
    5) Question text?
    (A) opt
    (B) opt
    (C) opt
    (D) opt
    [Answer: B]

  Format E (dash-prefixed):
    Q10: Question text?
    - A. opt
    - B. opt
    - C. opt
    - D. opt
    Answer - C

Every question must have exactly 4 options and a valid A/B/C/D answer.
Scanned (image-only) PDFs cannot be parsed — text must be embedded.


REQUIREMENTS
------------
  Python 3.10+
  flask
  pypdf          (for PDF upload)
  python-docx    (for DOCX upload)
  sqlite3        (built into Python — no install needed)
