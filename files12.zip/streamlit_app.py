"""
streamlit_app.py — Streamlit UI for Windows IT Agent
Replaces chainlit_app.py — zero Literal AI dependency.

Install:
    pip install streamlit langgraph-sdk aiosqlite

Run:
    streamlit run streamlit_app.py --server.port 8080
"""

import re
import uuid
import sqlite3
import json
import asyncio
from datetime import datetime
from pathlib import Path

import streamlit as st
from langgraph_sdk import get_client
from graph_rag import ingest_file, save_chat_resolution

LANGGRAPH_URL = "http://localhost:2024"
ASSISTANT_ID  = "windows_agent"
DB_PATH       = "sessions.db"

# ══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title = "IT Assistant",
    page_icon  = "🖥️",
    layout     = "wide"
)

# ══════════════════════════════════════════════════════════════════════════════
# LOCAL SESSION DB  (replaces Literal AI / Chainlit data layer)
# ══════════════════════════════════════════════════════════════════════════════

def _init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            thread_id  TEXT PRIMARY KEY,
            title      TEXT,
            messages   TEXT DEFAULT '[]',
            created_at TEXT,
            updated_at TEXT
        )
    """)
    conn.commit()
    conn.close()


def _save_message(thread_id: str, role: str, content: str, title: str = ""):
    conn  = sqlite3.connect(DB_PATH)
    row   = conn.execute(
        "SELECT messages, title FROM sessions WHERE thread_id=?", (thread_id,)
    ).fetchone()
    msgs  = json.loads(row[0]) if row else []
    saved_title = row[1] if row else ""
    msgs.append({"role": role, "content": content,
                 "ts": datetime.utcnow().isoformat()})
    now   = datetime.utcnow().isoformat()
    new_title = title or saved_title or (content[:50] if role == "user" else "")
    conn.execute("""
        INSERT INTO sessions (thread_id, title, messages, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(thread_id) DO UPDATE
        SET messages=excluded.messages,
            updated_at=excluded.updated_at,
            title=CASE WHEN title='' THEN excluded.title ELSE title END
    """, (thread_id, new_title, json.dumps(msgs), now, now))
    conn.commit()
    conn.close()


def _get_messages(thread_id: str) -> list[dict]:
    conn = sqlite3.connect(DB_PATH)
    row  = conn.execute(
        "SELECT messages FROM sessions WHERE thread_id=?", (thread_id,)
    ).fetchone()
    conn.close()
    return json.loads(row[0]) if row else []


def _get_all_sessions() -> list[dict]:
    conn  = sqlite3.connect(DB_PATH)
    rows  = conn.execute(
        "SELECT thread_id, title, updated_at FROM sessions ORDER BY updated_at DESC LIMIT 30"
    ).fetchall()
    conn.close()
    return [{"thread_id": r[0], "title": r[1] or r[0][:16]+"…",
             "updated_at": r[2]} for r in rows]


# ══════════════════════════════════════════════════════════════════════════════
# LANGGRAPH HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _lg():
    return get_client(url=LANGGRAPH_URL)


def _run_agent(thread_id: str, user_message: str) -> str:
    """Synchronous wrapper around the async LangGraph stream."""
    async def _stream():
        client = _lg()
        final  = ""
        async for chunk in client.runs.stream(
            thread_id    = thread_id,
            assistant_id = ASSISTANT_ID,
            input        = {"messages": [{"role": "user", "content": user_message}]},
            stream_mode  = "values"
        ):
            if chunk.data and "messages" in chunk.data:
                last    = chunk.data["messages"][-1]
                content = last.get("content", "") if isinstance(last, dict) \
                          else getattr(last, "content", "")
                if content:
                    final = content
        return final
    return asyncio.run(_stream())


def _load_langgraph_history(thread_id: str) -> list[dict]:
    """Load history directly from LangGraph state."""
    async def _fetch():
        try:
            client = _lg()
            state  = await client.threads.get_state(thread_id=thread_id)
            if not isinstance(state, dict):
                return []
            channel = state.get("values", {})
            if not isinstance(channel, dict):
                return []
            msgs = channel.get("messages", [])
            result = []
            for m in msgs:
                role    = (m.get("role","") or m.get("type","")) if isinstance(m, dict) \
                          else (getattr(m,"type",None) or getattr(m,"role",""))
                content = m.get("content","") if isinstance(m, dict) \
                          else getattr(m,"content","")
                if role == "human": role = "user"
                elif role in ("ai","AIMessage"): role = "assistant"
                if role and content:
                    result.append({"role": role, "content": str(content)})
            return result
        except Exception as e:
            st.warning(f"Could not load LangGraph history: {e}")
            return []
    return asyncio.run(_fetch())


def _create_lg_thread(thread_id: str):
    async def _create():
        try:
            await _lg().threads.create(thread_id=thread_id)
        except Exception:
            pass
    asyncio.run(_create())


# ══════════════════════════════════════════════════════════════════════════════
# SESSION STATE INIT
# ══════════════════════════════════════════════════════════════════════════════

_init_db()

if "thread_id"            not in st.session_state: st.session_state.thread_id            = ""
if "messages"             not in st.session_state: st.session_state.messages             = []
if "awaiting_save"        not in st.session_state: st.session_state.awaiting_save        = False
if "pending_resolution"   not in st.session_state: st.session_state.pending_resolution   = ""
if "awaiting_manual_fix"  not in st.session_state: st.session_state.awaiting_manual_fix  = False


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR — session history + new/resume
# ══════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.title("🖥️ IT Assistant")
    st.divider()

    # New session button
    if st.button("🆕 New Session", use_container_width=True):
        tid = str(uuid.uuid4())
        _create_lg_thread(tid)
        st.session_state.thread_id           = tid
        st.session_state.messages            = []
        st.session_state.awaiting_save       = False
        st.session_state.awaiting_manual_fix = False
        st.rerun()

    # Resume by pasting ID
    st.markdown("**Resume session**")
    paste_id = st.text_input("Paste Session ID", placeholder="xxxxxxxx-xxxx-…",
                             label_visibility="collapsed")
    if st.button("🔄 Load Session", use_container_width=True) and paste_id.strip():
        tid = paste_id.strip()
        # Try LangGraph first, fall back to local DB
        history = _load_langgraph_history(tid)
        if not history:
            history = _get_messages(tid)
        st.session_state.thread_id           = tid
        st.session_state.messages            = history
        st.session_state.awaiting_save       = False
        st.session_state.awaiting_manual_fix = False
        st.rerun()

    st.divider()

    # Recent sessions from local DB
    st.markdown("**Recent sessions**")
    for sess in _get_all_sessions():
        label = f"📋 {sess['title']}"
        if st.button(label, key=sess["thread_id"], use_container_width=True):
            tid     = sess["thread_id"]
            history = _load_langgraph_history(tid)
            if not history:
                history = _get_messages(tid)
            st.session_state.thread_id           = tid
            st.session_state.messages            = history
            st.session_state.awaiting_save       = False
            st.session_state.awaiting_manual_fix = False
            st.rerun()

    # File upload to RAG
    st.divider()
    st.markdown("**Add to knowledge base**")
    uploaded = st.file_uploader(
        "Upload PDF / Word / TXT",
        type=["pdf", "docx", "doc", "txt"],
        label_visibility="collapsed"
    )
    if uploaded:
        tmp_path = Path(f"/tmp/{uploaded.name}")
        tmp_path.write_bytes(uploaded.read())
        result = ingest_file(str(tmp_path), original_name=uploaded.name)
        st.success(result)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN AREA
# ══════════════════════════════════════════════════════════════════════════════

thread_id = st.session_state.thread_id

if not thread_id:
    # Welcome screen
    st.markdown("## 🖥️ Windows & GCP IT Assistant")
    st.info(
        "👈 Click **New Session** in the sidebar to start, "
        "or paste a Session ID to resume an existing incident."
    )
    st.stop()

# Show current session ID
st.caption(f"**Session ID:** `{thread_id}`  ·  Copy this to resume later or share with your team.")
st.divider()

# ── Render chat history ───────────────────────────────────────────────────────
for msg in st.session_state.messages:
    role    = msg["role"]
    content = msg["content"]
    with st.chat_message("user" if role == "user" else "assistant"):
        st.markdown(content)

# ── Resolved / Not Resolved buttons (shown after NEEDS_HUMAN or manual request) ──
if st.session_state.messages:
    last_msg = st.session_state.messages[-1]
    show_buttons = (
        last_msg["role"] == "assistant" and
        ("STATUS: NEEDS_HUMAN" in last_msg["content"] or
         st.session_state.awaiting_manual_fix)
    )
    if show_buttons:
        st.markdown("**What is the status of this incident?**")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("✅ Issue Resolved — Save Fix", use_container_width=True):
                st.session_state.awaiting_save      = True
                st.session_state.awaiting_manual_fix= False
                st.session_state.pending_resolution = last_msg["content"]
                st.rerun()
        with col2:
            if st.button("🔧 Not Resolved — Give Instructions", use_container_width=True):
                st.session_state.awaiting_manual_fix = True
                st.rerun()

# ── Save fix form ─────────────────────────────────────────────────────────────
if st.session_state.awaiting_save:
    st.markdown("### 💾 Save fix to knowledge base")
    with st.form("save_form"):
        topic      = st.text_input("Topic (descriptive name)",
                                   placeholder="Disk Full After Log Rotation")
        entry_type = st.radio("Type", ["INFORMATION_ONLY", "COMMAND_TASK"],
                              horizontal=True)
        submitted  = st.form_submit_button("Save")
        if submitted and topic:
            result = save_chat_resolution(
                topic      = topic,
                entry_type = entry_type,
                resolution = st.session_state.pending_resolution,
                session_id = thread_id,
            )
            st.success(result)
            st.session_state.awaiting_save = False
            st.rerun()

# ── Chat input ────────────────────────────────────────────────────────────────
placeholder = (
    "Provide manual fix instructions…"
    if st.session_state.awaiting_manual_fix
    else "Describe your issue…"
)

if prompt := st.chat_input(placeholder):
    # UUID paste detection — resume session
    stripped = prompt.strip()
    if re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
                stripped, re.IGNORECASE):
        history = _load_langgraph_history(stripped)
        if not history:
            history = _get_messages(stripped)
        st.session_state.thread_id           = stripped
        st.session_state.messages            = history
        st.session_state.awaiting_save       = False
        st.session_state.awaiting_manual_fix = False
        st.rerun()

    # Show user message
    with st.chat_message("user"):
        st.markdown(prompt)
    st.session_state.messages.append({"role": "user", "content": prompt})
    _save_message(thread_id, "user", prompt)

    # Run agent
    with st.chat_message("assistant"):
        with st.spinner("Agent working…"):
            reply = _run_agent(thread_id, prompt)
        st.markdown(reply)

    st.session_state.messages.append({"role": "assistant", "content": reply})
    _save_message(thread_id, "assistant", reply)

    if st.session_state.awaiting_manual_fix:
        st.session_state.awaiting_manual_fix = False

    st.rerun()
